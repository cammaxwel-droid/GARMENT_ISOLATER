@echo off
setlocal
set "garmentVswhere=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%garmentVswhere%" goto :missing
for /f "usebackq delims=" %%i in (`"%garmentVswhere%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "garmentVisualStudio=%%i"
if not defined garmentVisualStudio goto :missing
call "%garmentVisualStudio%\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul
if errorlevel 1 exit /b 1
set "garmentNativeOut=%~1"
if not defined garmentNativeOut set "garmentNativeOut=%TEMP%\GARMENT-Explorer-native-%RANDOM%-%RANDOM%"
if not exist "%garmentNativeOut%" mkdir "%garmentNativeOut%"
if errorlevel 1 exit /b 1
echo Native build output: %garmentNativeOut%
cl /nologo /std:c++17 /utf-8 /EHsc /MT /LD /O2 /W4 /WX /DUNICODE /D_UNICODE "%~dp0GarmentBackgroundDrop.cpp" /Fo"%garmentNativeOut%\GarmentBackgroundDrop.obj" /Fe"%garmentNativeOut%\GarmentBackgroundDrop.dll" /link /IMPLIB:"%garmentNativeOut%\GarmentBackgroundDrop.lib" /DEF:"%~dp0GarmentBackgroundDrop.def" shell32.lib ole32.lib user32.lib uuid.lib
exit /b %errorlevel%
:missing
echo Rebuilding requires Visual Studio C++ Build Tools and the Windows SDK.
exit /b 1
