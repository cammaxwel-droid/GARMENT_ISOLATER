#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlobj.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <new>
#include <stdexcept>

// Explorer runs only this native selection adapter. All image reads, inference,
// masks and PNG output remain in the separate, existing GARMENT worker.
static HMODULE module = nullptr;
static LONG objects = 0, locks = 0;
static const CLSID MenuClass = {0x821d6629,0x6618,0x4731,{0x96,0xb1,0xd3,0x48,0x10,0x75,0x58,0x97}};
static const wchar_t* Schema = L"garment-explorer-selection-v1";
static constexpr size_t MaxRequestBytes = 16 * 1024 * 1024;

static FORMATETC DropFormat() {
    FORMATETC format = {CF_HDROP, nullptr, DVASPECT_CONTENT, -1, TYMED_HGLOBAL};
    return format;
}

struct MediumLease {
    STGMEDIUM value = {};
    bool acquired = false;
    ~MediumLease() { if (acquired) ReleaseStgMedium(&value); }
};

static bool AbsoluteFilePath(const std::wstring& value) {
    return (value.size() >= 3 && ((value[0] >= L'A' && value[0] <= L'Z') ||
        (value[0] >= L'a' && value[0] <= L'z')) && value[1] == L':' &&
        (value[2] == L'\\' || value[2] == L'/')) ||
        (value.size() >= 3 && value[0] == L'\\' && value[1] == L'\\');
}

static HRESULT ReadSelectionPaths(IDataObject* data, std::vector<std::wstring>& paths) {
    if (!data) return E_INVALIDARG;
    FORMATETC format = DropFormat();
    MediumLease medium;
    HRESULT hr = data->GetData(&format, &medium.value);
    if (FAILED(hr)) return hr;
    medium.acquired = true;
    if (medium.value.tymed != TYMED_HGLOBAL || !medium.value.hGlobal) return DV_E_TYMED;
    const HDROP drop = reinterpret_cast<HDROP>(medium.value.hGlobal);
    const UINT count = DragQueryFileW(drop, 0xffffffff, nullptr, 0);
    if (!count) return E_INVALIDARG;
    try {
        paths.reserve(count);
        for (UINT index = 0; index < count; ++index) {
            const UINT length = DragQueryFileW(drop, index, nullptr, 0);
            if (!length) return E_UNEXPECTED;
            std::vector<wchar_t> name(static_cast<size_t>(length) + 1);
            if (DragQueryFileW(drop, index, name.data(), length + 1) != length) return E_UNEXPECTED;
            std::wstring path(name.data(), length);
            if (!AbsoluteFilePath(path)) return E_INVALIDARG;
            paths.push_back(std::move(path));
        }
    } catch (...) { return E_OUTOFMEMORY; }
    return S_OK;
}

static std::wstring JsonString(const std::wstring& value) {
    static const wchar_t hex[] = L"0123456789abcdef";
    std::wstring result = L"\"";
    for (wchar_t character : value) {
        switch (character) {
        case L'\"': result += L"\\\""; break;
        case L'\\': result += L"\\\\"; break;
        case L'\b': result += L"\\b"; break;
        case L'\f': result += L"\\f"; break;
        case L'\n': result += L"\\n"; break;
        case L'\r': result += L"\\r"; break;
        case L'\t': result += L"\\t"; break;
        default:
            if (character < 0x20) {
                result += L"\\u00";
                result += hex[(character >> 4) & 15];
                result += hex[character & 15];
            } else result += character;
        }
    }
    result += L'\"';
    return result;
}

static std::wstring SelectionJson(const std::wstring& id, const std::vector<std::wstring>& paths) {
    std::wstring result = L"{\"schema\":" + JsonString(Schema) +
        L",\"id\":" + JsonString(id) + L",\"sources\":[";
    for (size_t index = 0; index < paths.size(); ++index) {
        if (index) result += L',';
        result += JsonString(paths[index]);
    }
    result += L"]}\n";
    return result;
}

static HRESULT Utf8(const std::wstring& value, std::string& output) {
    if (value.size() > INT_MAX) return HRESULT_FROM_WIN32(ERROR_FILE_TOO_LARGE);
    const int length = static_cast<int>(value.size());
    const int bytes = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.data(), length, nullptr, 0, nullptr, nullptr);
    if (!bytes) return HRESULT_FROM_WIN32(GetLastError());
    output.resize(static_cast<size_t>(bytes));
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.data(), length, output.data(), bytes, nullptr, nullptr) != bytes)
        return HRESULT_FROM_WIN32(GetLastError());
    return S_OK;
}

// Always quote one argument using the Windows CRT rules. There is no cmd.exe
// expansion and selected image paths never enter this process command line.
static std::wstring QuoteArgument(const std::wstring& value) {
    std::wstring result = L"\"";
    size_t slashes = 0;
    for (wchar_t character : value) {
        if (character == L'\\') { ++slashes; continue; }
        if (character == L'\"') result.append(slashes * 2 + 1, L'\\');
        else result.append(slashes, L'\\');
        result += character;
        slashes = 0;
    }
    result.append(slashes * 2, L'\\');
    result += L'\"';
    return result;
}

static HRESULT MakeDirectory(const std::wstring& path) {
    if (CreateDirectoryW(path.c_str(), nullptr)) return S_OK;
    const DWORD error = GetLastError();
    if (error != ERROR_ALREADY_EXISTS) return HRESULT_FROM_WIN32(error);
    const DWORD attributes = GetFileAttributesW(path.c_str());
    return attributes != INVALID_FILE_ATTRIBUTES && (attributes & FILE_ATTRIBUTE_DIRECTORY)
        ? S_OK : HRESULT_FROM_WIN32(ERROR_DIRECTORY);
}

static HRESULT ToolRoot(std::wstring& root) {
    wchar_t filename[32768];
    const DWORD length = GetModuleFileNameW(module, filename, 32768);
    if (!length || length >= 32768) return E_UNEXPECTED;
    root.assign(filename, length);
    for (int index = 0; index < 2; ++index) {
        const size_t split = root.find_last_of(L"\\/");
        if (split == std::wstring::npos) return E_UNEXPECTED;
        root.resize(split);
    }
    return root.empty() ? E_UNEXPECTED : S_OK;
}

static HRESULT PublishRequest(const std::wstring& queue, const std::wstring& id,
    const std::string& payload, std::wstring& published) {
    if (payload.size() > MaxRequestBytes) return HRESULT_FROM_WIN32(ERROR_FILE_TOO_LARGE);
    const std::wstring temporary = queue + L"\\" + id + L".writing.json";
    const std::wstring ready = queue + L"\\" + id + L".ready.json";
    HANDLE file = CreateFileW(temporary.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return HRESULT_FROM_WIN32(GetLastError());
    DWORD written = 0;
    bool ok = WriteFile(file, payload.data(), static_cast<DWORD>(payload.size()), &written, nullptr) != FALSE;
    ok = ok && written == payload.size();
    if (ok) ok = FlushFileBuffers(file) != FALSE;
    DWORD error = ok ? ERROR_SUCCESS : GetLastError();
    if (!CloseHandle(file)) { if (ok) error = GetLastError(); ok = false; }
    if (!ok) {
        DeleteFileW(temporary.c_str());
        return HRESULT_FROM_WIN32(error ? error : ERROR_WRITE_FAULT);
    }
    // Same-directory publication is atomic. No replacement of any prior job.
    if (!MoveFileExW(temporary.c_str(), ready.c_str(), MOVEFILE_WRITE_THROUGH)) {
        error = GetLastError();
        DeleteFileW(temporary.c_str());
        return HRESULT_FROM_WIN32(error);
    }
    published = ready;
    return S_OK;
}

static HRESULT LaunchWorker(const std::wstring& queue) {
    std::wstring root;
    HRESULT hr = ToolRoot(root);
    if (FAILED(hr)) return hr;
    const std::wstring script = root + L"\\Background Remover.ps1";
    const DWORD attributes = GetFileAttributesW(script.c_str());
    if (attributes == INVALID_FILE_ATTRIBUTES || (attributes & FILE_ATTRIBUTE_DIRECTORY))
        return HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND);
    wchar_t system[32768];
    const UINT length = GetSystemDirectoryW(system, 32768);
    if (!length || length >= 32768) return HRESULT_FROM_WIN32(GetLastError());
    const std::wstring executable = std::wstring(system, length) + L"\\WindowsPowerShell\\v1.0\\powershell.exe";
    const std::wstring command = QuoteArgument(executable) +
        L" -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File " +
        QuoteArgument(script) + L" -ExplorerQueue " + QuoteArgument(queue);
    if (command.size() >= 32767) return HRESULT_FROM_WIN32(ERROR_FILENAME_EXCED_RANGE);
    std::vector<wchar_t> mutableCommand(command.begin(), command.end());
    mutableCommand.push_back(0);
    STARTUPINFOW startup = {};
    startup.cb = sizeof(startup);
    startup.dwFlags = STARTF_USESHOWWINDOW;
    startup.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION process = {};
    if (!CreateProcessW(executable.c_str(), mutableCommand.data(), nullptr, nullptr, FALSE,
        CREATE_NO_WINDOW, nullptr, root.c_str(), &startup, &process))
        return HRESULT_FROM_WIN32(GetLastError());
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
    return S_OK;
}

static HRESULT QueueSelection(IDataObject* data, std::wstring& published) {
    std::vector<std::wstring> paths;
    HRESULT hr = ReadSelectionPaths(data, paths);
    if (FAILED(hr)) return hr;
    GUID id;
    hr = CoCreateGuid(&id);
    if (FAILED(hr)) return hr;
    wchar_t guid[40];
    if (!StringFromGUID2(id, guid, 40)) return E_UNEXPECTED;
    std::wstring identifier;
    for (wchar_t character : std::wstring(guid)) {
        if (character == L'{' || character == L'}' || character == L'-') continue;
        identifier += character >= L'A' && character <= L'F' ? character + (L'a' - L'A') : character;
    }
    std::string payload;
    hr = Utf8(SelectionJson(identifier, paths), payload);
    if (FAILED(hr)) return hr;
    PWSTR local = nullptr;
    hr = SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &local);
    if (FAILED(hr)) return hr;
    const std::wstring base = std::wstring(local) + L"\\GARMENT-ISOLATER";
    CoTaskMemFree(local);
    const std::wstring explorer = base + L"\\Explorer";
    const std::wstring queue = explorer + L"\\Queue";
    for (const auto& folder : {base, explorer, queue}) {
        hr = MakeDirectory(folder);
        if (FAILED(hr)) return hr;
    }
    hr = PublishRequest(queue, identifier, payload, published);
    if (FAILED(hr)) return hr;
    // A published request survives launch failure and can be consumed later.
    return LaunchWorker(queue);
}

class Target final : public IDropTarget {
    LONG refs = 1;
    bool acceptsFiles = false;
public:
    Target() { InterlockedIncrement(&objects); }
    ~Target() { InterlockedDecrement(&objects); }
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, void** value) override {
        if (!value) return E_POINTER;
        *value = nullptr;
        if (iid != IID_IUnknown && iid != IID_IDropTarget) return E_NOINTERFACE;
        *value = static_cast<IDropTarget*>(this);
        AddRef();
        return S_OK;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return static_cast<ULONG>(InterlockedIncrement(&refs)); }
    ULONG STDMETHODCALLTYPE Release() override {
        const LONG count = InterlockedDecrement(&refs);
        if (!count) delete this;
        return static_cast<ULONG>(count);
    }
    HRESULT STDMETHODCALLTYPE DragEnter(IDataObject* data, DWORD, POINTL, DWORD* effect) override {
        if (!effect) return E_POINTER;
        FORMATETC format = DropFormat();
        acceptsFiles = data && data->QueryGetData(&format) == S_OK;
        // Shell verb invocation simulates a drop. NONE here rejects the
        // selection before Drop can publish it. Accept only permitted COPY.
        *effect = acceptsFiles ? (*effect & DROPEFFECT_COPY) : DROPEFFECT_NONE;
        return S_OK;
    }
    HRESULT STDMETHODCALLTYPE DragOver(DWORD, POINTL, DWORD* effect) override {
        if (!effect) return E_POINTER;
        *effect = acceptsFiles ? (*effect & DROPEFFECT_COPY) : DROPEFFECT_NONE;
        return S_OK;
    }
    HRESULT STDMETHODCALLTYPE DragLeave() override { acceptsFiles = false; return S_OK; }
    HRESULT STDMETHODCALLTYPE Drop(IDataObject* data, DWORD, POINTL, DWORD* effect) override {
        if (!effect) return E_POINTER;
        *effect = DROPEFFECT_NONE;
        std::wstring published;
        HRESULT hr;
        try { hr = QueueSelection(data, published); }
        catch (...) { hr = E_OUTOFMEMORY; }
        if (FAILED(hr)) {
            wchar_t code[16];
            wsprintfW(code, L"0x%08X", static_cast<UINT>(hr));
            std::wstring message = L"Windows could not start Remove background (error " + std::wstring(code) + L").\n\n";
            if (!published.empty()) message += L"Your complete selection is saved here:\n" + published +
                L"\n\nRun Queued Background Jobs.cmd after repairing the launcher. Do not submit the same selection again while this request remains queued.\n\n";
            else message += L"The selection was not queued.\n\n";
            if (hr == HRESULT_FROM_WIN32(ERROR_FILE_TOO_LARGE)) message += L"The selection request exceeds the 16 MiB limit. Select a smaller batch.\n\n";
            message += L"No image files were changed by the Explorer handler.";
            MessageBoxW(nullptr, message.c_str(), L"GARMENT ISOLATER - request did not start", MB_OK | MB_ICONERROR);
        }
        return hr;
    }
};

class Factory final : public IClassFactory {
    LONG refs = 1;
public:
    Factory() { InterlockedIncrement(&objects); }
    ~Factory() { InterlockedDecrement(&objects); }
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, void** value) override {
        if (!value) return E_POINTER;
        *value = nullptr;
        if (iid != IID_IUnknown && iid != IID_IClassFactory) return E_NOINTERFACE;
        *value = static_cast<IClassFactory*>(this);
        AddRef();
        return S_OK;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return static_cast<ULONG>(InterlockedIncrement(&refs)); }
    ULONG STDMETHODCALLTYPE Release() override {
        const LONG count = InterlockedDecrement(&refs);
        if (!count) delete this;
        return static_cast<ULONG>(count);
    }
    HRESULT STDMETHODCALLTYPE CreateInstance(IUnknown* outer, REFIID iid, void** value) override {
        if (!value) return E_POINTER;
        *value = nullptr;
        if (outer) return CLASS_E_NOAGGREGATION;
        Target* target = new (std::nothrow) Target();
        if (!target) return E_OUTOFMEMORY;
        const HRESULT hr = target->QueryInterface(iid, value);
        target->Release();
        return hr;
    }
    HRESULT STDMETHODCALLTYPE LockServer(BOOL locked) override {
        if (locked) InterlockedIncrement(&locks); else InterlockedDecrement(&locks);
        return S_OK;
    }
};

extern "C" HRESULT __stdcall DllGetClassObject(REFCLSID clsid, REFIID iid, void** value) {
    if (!value) return E_POINTER;
    *value = nullptr;
    if (clsid != MenuClass) return CLASS_E_CLASSNOTAVAILABLE;
    Factory* factory = new (std::nothrow) Factory();
    if (!factory) return E_OUTOFMEMORY;
    const HRESULT hr = factory->QueryInterface(iid, value);
    factory->Release();
    return hr;
}

extern "C" HRESULT __stdcall DllCanUnloadNow() {
    return objects == 0 && locks == 0 ? S_OK : S_FALSE;
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        module = instance;
        DisableThreadLibraryCalls(instance);
    }
    return TRUE;
}
