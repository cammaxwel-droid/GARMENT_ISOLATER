param([string]$ToolRoot)
$ErrorActionPreference = 'Stop'
if (-not $ToolRoot) { $ToolRoot = Split-Path $PSScriptRoot -Parent }
$taskRoot = [System.IO.Path]::GetFullPath($ToolRoot).TrimEnd('\')
$taskKeys = @('Software\Classes\SystemFileAssociations\image\shell\GarmentIsolater.RemoveBackground','Software\Classes\CLSID\{821D6629-6618-4731-96B1-D34810755897}')
$taskRegistry = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry64)
try {
  foreach ($taskKeyName in $taskKeys) {
    $taskKey = $taskRegistry.OpenSubKey($taskKeyName)
    if ($taskKey) {
      try { if ([string]$taskKey.GetValue('GarmentIsolaterOwner') -ne $taskRoot) { throw "That menu registration belongs to a different tool location. It was preserved: $taskKeyName" } }
      finally { $taskKey.Dispose() }
    }
  }
  foreach ($taskKeyName in $taskKeys) { $taskRegistry.DeleteSubKeyTree($taskKeyName,$false) }
} finally { $taskRegistry.Dispose() }
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class GarmentExplorerNotify { [DllImport("shell32.dll")] public static extern void SHChangeNotify(uint evt, uint flags, IntPtr first, IntPtr second); }'
[GarmentExplorerNotify]::SHChangeNotify(0x08000000,0,[IntPtr]::Zero,[IntPtr]::Zero)
Write-Output 'Removed this copy''s File Explorer menu action. All image files, output batches and manual tools were preserved.'
