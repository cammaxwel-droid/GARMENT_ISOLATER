param([string]$ToolRoot, [switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
if (-not $ToolRoot) { $ToolRoot = Split-Path $PSScriptRoot -Parent }
$taskRoot = (Resolve-Path -LiteralPath $ToolRoot).ProviderPath
$taskDll = Join-Path $taskRoot 'ExplorerIntegration\GarmentBackgroundDrop.dll'
$taskNode = Join-Path $taskRoot 'runtime\node.exe'
$taskGui = Join-Path $taskRoot 'Background Remover.ps1'
foreach ($taskRequired in @($taskDll,$taskNode,$taskGui)) {
  if (-not (Test-Path -LiteralPath $taskRequired -PathType Leaf)) { throw "A required file is missing: $taskRequired. Extract the complete GARMENT ISOLATER tool folder." }
}
$taskManifest = Get-Content -LiteralPath (Join-Path $taskRoot 'PACKAGE-MANIFEST.json') -Raw | ConvertFrom-Json
$taskExpected = @($taskManifest.manifest | Where-Object { $_.path -eq 'ExplorerIntegration/GarmentBackgroundDrop.dll' })
if ($taskExpected.Count -ne 1 -or (Get-FileHash -LiteralPath $taskDll -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskExpected[0].sha256) { throw 'The Explorer adapter does not match its package manifest. No registration was changed.' }
if ((Get-FileHash -LiteralPath $taskNode -Algorithm SHA256).Hash -ne '3602F2BB1A10F2CBAB4C36886218A33C1AB3DB87290E73B033C46C77147D0237') { throw 'The processing engine differs from this verified release. No registration was changed.' }
$taskClsid = '{821D6629-6618-4731-96B1-D34810755897}'
$taskClassKey = 'Software\Classes\CLSID\' + $taskClsid
$taskVerbKey = 'Software\Classes\SystemFileAssociations\image\shell\GarmentIsolater.RemoveBackground'
$taskUserRegistry = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry64)
try {
  foreach ($taskKeyName in @($taskClassKey,$taskVerbKey)) {
    $taskExisting = $taskUserRegistry.OpenSubKey($taskKeyName)
    if ($taskExisting) {
      try { if ([string]$taskExisting.GetValue('GarmentIsolaterOwner') -ne $taskRoot) { throw "The registration name already belongs to another location: $taskKeyName. Existing settings were preserved." } }
      finally { $taskExisting.Dispose() }
    }
  }
  if ($CheckOnly) { Write-Output 'Explorer adapter and processing engine verified; per-user menu registration is available.'; exit 0 }
  $taskClass = $taskUserRegistry.CreateSubKey($taskClassKey)
  try { $taskClass.SetValue('', 'GARMENT ISOLATER Remove background'); $taskClass.SetValue('GarmentIsolaterOwner',$taskRoot) } finally { $taskClass.Dispose() }
  $taskServer = $taskUserRegistry.CreateSubKey($taskClassKey + '\InprocServer32')
  try { $taskServer.SetValue('', $taskDll); $taskServer.SetValue('ThreadingModel','Apartment') } finally { $taskServer.Dispose() }
  $taskVerb = $taskUserRegistry.CreateSubKey($taskVerbKey)
  try { $taskVerb.SetValue('', 'Remove background'); $taskVerb.SetValue('MUIVerb','Remove background'); $taskVerb.SetValue('MultiSelectModel','Player'); $taskVerb.SetValue('GarmentIsolaterOwner',$taskRoot) } finally { $taskVerb.Dispose() }
  $taskDrop = $taskUserRegistry.CreateSubKey($taskVerbKey + '\DropTarget')
  try { $taskDrop.SetValue('CLSID',$taskClsid) } finally { $taskDrop.Dispose() }
} finally { $taskUserRegistry.Dispose() }
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class GarmentExplorerNotify { [DllImport("shell32.dll")] public static extern void SHChangeNotify(uint evt, uint flags, IntPtr first, IntPtr second); }'
[GarmentExplorerNotify]::SHChangeNotify(0x08000000,0,[IntPtr]::Zero,[IntPtr]::Zero)
$taskReceiptRoot = Join-Path $env:LOCALAPPDATA 'GARMENT-ISOLATER\Explorer\Installations'
[void][System.IO.Directory]::CreateDirectory($taskReceiptRoot)
$taskReceipt = [ordered]@{status='installed';version=$taskManifest.manual_tools_version;tool_root=$taskRoot;dll=$taskDll;dll_sha256=(Get-FileHash -LiteralPath $taskDll -Algorithm SHA256).Hash;registry_scope='Current user only';verb=$taskVerbKey;clsid=$taskClsid;security_settings_changed=$false;installed_utc=(Get-Date).ToUniversalTime().ToString('o')}
[System.IO.File]::WriteAllText((Join-Path $taskReceiptRoot ('install-' + [guid]::NewGuid().ToString('N') + '.json')),($taskReceipt | ConvertTo-Json -Depth 4),(New-Object System.Text.UTF8Encoding($false)))
Write-Output 'Installed Remove background for this Windows user. Select images, then Shift + right-click > Remove background, or right-click > Show more options > Remove background.'
Write-Output 'Each run saves a new batch folder beside the selected images. Masks and cutouts are created automatically. Original images remain untouched.'
