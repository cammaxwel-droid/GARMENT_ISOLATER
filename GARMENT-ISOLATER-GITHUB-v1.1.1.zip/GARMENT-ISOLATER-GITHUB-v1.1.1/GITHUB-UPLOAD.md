# Upload this repository to GitHub

1. Extract **GARMENT-ISOLATER-GITHUB-v1.1.1.zip**.
2. Open the extracted `GARMENT-ISOLATER-GITHUB-v1.1.1` folder. `README.md` should be visible beside the launchers.
3. Create an empty repository on GitHub, using your preferred name and visibility.
4. Choose **Add file > Upload files**, then drag the contents of this folder into the upload area. Upload the contents so `README.md` is at the repository root.
5. Enter a commit message such as **Add GARMENT ISOLATER background remover**, then commit the upload.

Upload the clean extracted package before running setup in it. First-run downloads are local dependencies and belong outside the source upload. If you use GitHub Desktop or Git instead, `.gitignore` excludes those downloaded files.

Uploading the ZIP itself stores an archive file; extracting and uploading its contents gives visitors a browsable repository. You can also attach the ZIP to a GitHub Release as a convenient download.

This package was kept below GitHub's browser limits: 25 MiB per file and 100 files per upload. See [GitHub's official upload instructions](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository).

After cloning or downloading the repository, users run **Setup Windows.cmd**, then **Background Remover.cmd**. Only the optional menu installer changes the current user's Explorer registration.
