@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0ExplorerIntegration\Uninstall.ps1"
if errorlevel 1 (
  echo.
  echo The menu removal stopped. Read the message above.
)
pause
endlocal
