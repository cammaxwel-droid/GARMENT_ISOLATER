# Local model files

**Setup Windows.cmd** downloads and checks `u2net.onnx` and `u2netp.onnx` here. The large model files are excluded from Git and the source ZIP.

Detailed processing and the Explorer action use U2NET. Quick processing uses U2NETP. Both models run locally after setup; their checksums and upstream URLs are recorded in `DEPENDENCIES.json`.
