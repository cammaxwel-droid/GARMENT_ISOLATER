param(
  [switch]$CheckOnly,
  [switch]$ValidateUI,
  [string]$ExplorerRequest,
  [string]$ExplorerQueue,
  [string]$ToolRoot = $PSScriptRoot
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$toolRoot = [System.IO.Path]::GetFullPath($ToolRoot)
$nodePath = Join-Path $toolRoot 'runtime\node.exe'
$runnerPath = Join-Path $toolRoot 'scripts\manual_batch.cjs'
$runtimePath = Join-Path $toolRoot 'runtime'
$editorPath = Join-Path $toolRoot 'mask-editor.html'
$quickModel = Join-Path $toolRoot 'models\u2netp.onnx'
$detailedModel = Join-Path $toolRoot 'models\u2net.onnx'
foreach ($required in @($nodePath, $runnerPath, $editorPath, (Join-Path $toolRoot 'helpers\asset_pipeline.cjs'), (Join-Path $toolRoot 'helpers\generate_mask.cjs'))) {
  if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
    throw "A required tool file is missing: $required. Extract the complete tool folder before launching."
  }
}
if (-not (Test-Path -LiteralPath $quickModel -PathType Leaf) -and -not (Test-Path -LiteralPath $detailedModel -PathType Leaf)) {
  throw 'The offline model files are missing. Keep the included models folder with this tool.'
}
function Test-ExplorerAbsolutePath([string]$Value) {
  return (-not [string]::IsNullOrWhiteSpace($Value) -and [System.IO.Path]::IsPathRooted($Value) -and $Value -notmatch '^[A-Za-z]:(?:$|[^\\/])|^\\(?!\\)')
}
function Read-ExplorerSelection([string]$RequestPath) {
  $leaf = [System.IO.Path]::GetFileName($RequestPath)
  if ($leaf -cnotmatch '^[0-9a-fA-F]{32}\.(ready|running)\.json$') { throw 'Explorer request filenames must contain a 32-character GUID and ready.json or running.json.' }
  $requestId = $leaf.Substring(0, 32).ToLowerInvariant()
  $file = Get-Item -LiteralPath $RequestPath -ErrorAction Stop
  if ($file.PSIsContainer -or $file.Length -gt 16777216) { throw 'The Explorer request must be a JSON file no larger than 16 MB.' }
  $request = [System.IO.File]::ReadAllText($file.FullName, [System.Text.UTF8Encoding]::new($false, $true)) | ConvertFrom-Json -ErrorAction Stop
  if ($request.schema -cne 'garment-explorer-selection-v1') { throw 'The Explorer selection schema is not supported.' }
  $parsedId = [Guid]::Empty
  if (-not [Guid]::TryParse([string]$request.id, [ref]$parsedId) -or $parsedId.ToString('N') -ne $requestId) { throw 'The Explorer request GUID does not match its filename.' }
  if ($request.sources -isnot [System.Array] -or $request.sources.Count -eq 0) { throw 'The Explorer request must contain a non-empty sources array.' }
  $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
  $paths = New-Object 'System.Collections.Generic.List[string]'
  foreach ($source in $request.sources) {
    if ($source -isnot [string] -or -not (Test-ExplorerAbsolutePath $source)) { throw 'Every Explorer selection must be an absolute file path.' }
    $item = Get-Item -LiteralPath $source -ErrorAction Stop
    if ($item.PSIsContainer) { throw "Explorer selection is a folder, not an image file: $source" }
    if ($seen.Add($item.FullName)) { $paths.Add($item.FullName) }
  }
  return [PSCustomObject]@{ Id=$requestId; Sources=$paths.ToArray(); SelectedCount=$request.sources.Count; DuplicateCount=($request.sources.Count-$paths.Count) }
}
function Get-ExplorerGroups([string[]]$Paths) {
  $indices = New-Object 'System.Collections.Generic.Dictionary[string,int]' ([System.StringComparer]::OrdinalIgnoreCase)
  $groups = New-Object 'System.Collections.Generic.List[object]'
  foreach ($source in $Paths) {
    $parent = [System.IO.Path]::GetDirectoryName($source)
    if (-not $indices.ContainsKey($parent)) {
      $indices.Add($parent, $groups.Count)
      $groups.Add([PSCustomObject]@{ OutputParent=$parent; Sources=(New-Object 'System.Collections.Generic.List[string]'); Status='pending'; Folder=$null; Error=$null })
    }
    $groups[$indices[$parent]].Sources.Add($source)
  }
  return ,$groups.ToArray()
}
function Claim-ExplorerReady([string]$QueuePath) {
  $candidates = @(Get-ChildItem -LiteralPath $QueuePath -File -Filter '*.ready.json' -ErrorAction Stop | Where-Object { $_.Name -cmatch '^[0-9a-fA-F]{32}\.ready\.json$' } | Sort-Object LastWriteTimeUtc, Name)
  foreach ($candidate in $candidates) {
    $running = Join-Path $QueuePath ($candidate.Name.Substring(0,32) + '.running.json')
    try { [System.IO.File]::Move($candidate.FullName, $running); return $running }
    catch {
      if (-not (Test-Path -LiteralPath $candidate.FullName -PathType Leaf)) { continue }
      throw "Could not claim the Explorer request. Its ready file was preserved: $($candidate.FullName). $($_.Exception.Message)"
    }
  }
  return $null
}
function Write-ExplorerReceipt([string]$QueuePath, [string]$Id, [string]$Status, $Receipt) {
  if ($Id -cnotmatch '^[0-9a-f]{32}$' -or $Status -notin @('complete','error')) { throw 'Invalid Explorer receipt identity or status.' }
  $destination = Join-Path $QueuePath "$Id.$Status.json"
  $temporary = Join-Path $QueuePath ("$Id.receipt." + [Guid]::NewGuid().ToString('N') + '.partial')
  $bytes = [System.Text.UTF8Encoding]::new($false).GetBytes(($Receipt | ConvertTo-Json -Depth 8) + [Environment]::NewLine)
  $stream = [System.IO.File]::Open($temporary, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
  try { $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
  try { [System.IO.File]::Move($temporary,$destination) }
  catch { if (Test-Path -LiteralPath $temporary -PathType Leaf) { Remove-Item -LiteralPath $temporary -Force }; throw }
  return $destination
}

$script:explorerMode = (-not [string]::IsNullOrWhiteSpace($ExplorerQueue) -or -not [string]::IsNullOrWhiteSpace($ExplorerRequest))
$script:explorerQueuePath = $null
$script:explorerMutex = $null
$script:explorerMutexHeld = $false
$script:explorerJob = $null
$script:explorerPaused = $false
if ($script:explorerMode) {
  try {
    if ($ExplorerRequest) {
      if (-not (Test-ExplorerAbsolutePath $ExplorerRequest) -or [System.IO.Path]::GetFileName($ExplorerRequest) -cnotmatch '^[0-9a-fA-F]{32}\.ready\.json$') { throw 'Choose an absolute GUID.ready.json Explorer request path.' }
      if (-not $ExplorerQueue) { $ExplorerQueue = [System.IO.Path]::GetDirectoryName($ExplorerRequest) }
    }
    if (-not (Test-ExplorerAbsolutePath $ExplorerQueue)) { throw 'The Explorer queue must be an absolute folder path.' }
    $queueItem = Get-Item -LiteralPath $ExplorerQueue -ErrorAction Stop
    if (-not $queueItem.PSIsContainer) { throw 'The Explorer queue path is not a folder.' }
    $script:explorerQueuePath = $queueItem.FullName
    if ($ExplorerRequest -and -not [string]::Equals([System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($ExplorerRequest)), $script:explorerQueuePath, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'The Explorer request must be inside its queue folder.' }
  } catch {
    if (-not $CheckOnly -and -not $ValidateUI) { [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'GARMENT ISOLATER - Explorer request',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error) }
    throw
  }
}
if ($CheckOnly) {
  Write-Output 'Portable launcher paths are complete.'
  if ($script:explorerMode) { Write-Output ("Explorer queue path is ready: " + $script:explorerQueuePath) }
  exit 0
}
if ($script:explorerMode -and -not $ValidateUI) {
  $mutexName = 'Local\GARMENT.Explorer.' + [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  $script:explorerMutex = New-Object System.Threading.Mutex($false,$mutexName)
  try { $script:explorerMutexHeld = $script:explorerMutex.WaitOne(0) }
  catch [System.Threading.AbandonedMutexException] { $script:explorerMutexHeld = $true }
  if (-not $script:explorerMutexHeld) { $script:explorerMutex.Dispose(); Write-Output 'The open GARMENT ISOLATER Explorer window will process queued requests.'; exit 0 }
}

# Quote arguments for a direct CreateProcess call; no shell receives source filenames.
function ConvertTo-WindowsArgument([string]$Value) {
  if ($Value -notmatch '[\s"]' -and $Value.Length -gt 0) { return $Value }
  $builder = New-Object System.Text.StringBuilder
  [void]$builder.Append('"')
  $slashes = 0
  foreach ($character in $Value.ToCharArray()) {
    if ($character -eq '\') { $slashes++; continue }
    if ($character -eq '"') {
      [void]$builder.Append(('\' * ($slashes * 2 + 1)))
      [void]$builder.Append('"')
    } else {
      [void]$builder.Append(('\' * $slashes))
      [void]$builder.Append($character)
    }
    $slashes = 0
  }
  [void]$builder.Append(('\' * ($slashes * 2)))
  [void]$builder.Append('"')
  return $builder.ToString()
}

$script:worker = $null
$script:requestPath = $null
$script:lastOutput = $null
$script:outputTask = $null
$script:errorTask = $null
$script:outputEnded = $false
$script:errorEnded = $false
$script:reportedError = $false
$script:lastWorkerFolder = $null
$script:lastWorkerComplete = $false
$script:lastWorkerError = $null

$form = New-Object System.Windows.Forms.Form
$form.Text = 'GARMENT ISOLATER - Background Remover'
$form.ClientSize = New-Object System.Drawing.Size(780, 660)
$form.MinimumSize = New-Object System.Drawing.Size(796, 699)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)

$intro = New-Object System.Windows.Forms.Label
$intro.Text = 'Choose garment images and an output folder. Original files stay untouched.'
$intro.AutoSize = $true
$intro.Location = New-Object System.Drawing.Point(16, 16)
$form.Controls.Add($intro)

$sources = New-Object System.Windows.Forms.ListBox
$sources.Location = New-Object System.Drawing.Point(16, 80)
$sources.Size = New-Object System.Drawing.Size(748, 170)
$sources.SelectionMode = 'MultiExtended'
$sources.HorizontalScrollbar = $true
$sources.Anchor = 'Top, Left, Right'
$form.Controls.Add($sources)

function New-Button([string]$Text, [int]$X, [int]$Y, [int]$Width) {
  $button = New-Object System.Windows.Forms.Button
  $button.Text = $Text
  $button.Location = New-Object System.Drawing.Point($X, $Y)
  $button.Size = New-Object System.Drawing.Size($Width, 30)
  $form.Controls.Add($button)
  return $button
}
$addButton = New-Button 'Add images...' 16 42 130
$removeButton = New-Button 'Remove selected' 156 42 145
$clearButton = New-Button 'Clear list' 311 42 110

$folderButton = New-Button 'Output folder...' 16 267 135
$outputText = New-Object System.Windows.Forms.TextBox
$outputText.Location = New-Object System.Drawing.Point(164, 269)
$outputText.Size = New-Object System.Drawing.Size(600, 28)
$outputText.ReadOnly = $true
$outputText.Anchor = 'Top, Left, Right'
$form.Controls.Add($outputText)

$modelLabel = New-Object System.Windows.Forms.Label
$modelLabel.Text = 'Model:'
$modelLabel.AutoSize = $true
$modelLabel.Location = New-Object System.Drawing.Point(16, 314)
$form.Controls.Add($modelLabel)
$modelBox = New-Object System.Windows.Forms.ComboBox
$modelBox.DropDownStyle = 'DropDownList'
$modelBox.Location = New-Object System.Drawing.Point(74, 311)
$modelBox.Size = New-Object System.Drawing.Size(350, 29)
if (Test-Path -LiteralPath $detailedModel -PathType Leaf) { [void]$modelBox.Items.Add('Detailed - U2NET') }
if (Test-Path -LiteralPath $quickModel -PathType Leaf) { [void]$modelBox.Items.Add('Quick - U2NETP') }
$modelBox.SelectedIndex = 0
$form.Controls.Add($modelBox)

$forceBox = New-Object System.Windows.Forms.CheckBox
$forceBox.Text = 'Re-segment images that already have transparency'
$forceBox.Location = New-Object System.Drawing.Point(16, 349)
$forceBox.Size = New-Object System.Drawing.Size(720, 26)
$form.Controls.Add($forceBox)
$detailLabel = New-Object System.Windows.Forms.Label
$detailLabel.Text = 'A fresh batch folder stores source PNGs, masks and cutouts at original size. Review fine details.'
$detailLabel.AutoSize = $true
$detailLabel.Location = New-Object System.Drawing.Point(16, 381)
$form.Controls.Add($detailLabel)

$startButton = New-Button 'Remove backgrounds' 16 412 175
$showButton = New-Button 'Open output folder' 205 412 160
$showButton.Enabled = $false
$editorButton = New-Button 'Open Mask Editor' 379 412 160
$applyButton = New-Button 'Apply saved mask...' 553 412 211

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(16, 458)
$progress.Size = New-Object System.Drawing.Size(748, 20)
$progress.Anchor = 'Top, Left, Right'
$form.Controls.Add($progress)
$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = 'Ready.'
$statusLabel.Location = New-Object System.Drawing.Point(16, 487)
$statusLabel.Size = New-Object System.Drawing.Size(748, 45)
$statusLabel.Anchor = 'Top, Left, Right'
$form.Controls.Add($statusLabel)
$log = New-Object System.Windows.Forms.TextBox
$log.Location = New-Object System.Drawing.Point(16, 535)
$log.Size = New-Object System.Drawing.Size(748, 109)
$log.Multiline = $true
$log.ReadOnly = $true
$log.ScrollBars = 'Both'
$log.WordWrap = $false
$log.Anchor = 'Top, Bottom, Left, Right'
$form.Controls.Add($log)

function Add-Log([string]$Message) { $log.AppendText($Message + [Environment]::NewLine) }
function Set-Running([bool]$Running) {
  foreach ($control in @($addButton,$removeButton,$clearButton,$folderButton,$modelBox,$forceBox,$startButton,$applyButton)) { $control.Enabled = -not $Running }
}
function Read-WorkerLine([string]$Line) {
  if ([string]::IsNullOrWhiteSpace($Line)) { return }
  try {
    $event = $Line | ConvertFrom-Json
    if ($event.message) { $statusLabel.Text = [string]$event.message; Add-Log ([string]$event.message) }
    if ($event.folder) { $script:lastOutput = [string]$event.folder; $showButton.Enabled = $true }
    if ($event.folder) { $script:lastWorkerFolder = [string]$event.folder }
    if ($event.total) { $progress.Maximum = [Math]::Max(1, [int]$event.total); $progress.Value = [Math]::Min($progress.Maximum,[Math]::Max(0,[int]$event.completed)) }
    if ($event.kind -eq 'complete') { $script:lastWorkerComplete = $true }
    if ($event.kind -eq 'error') { $script:reportedError = $true; $script:lastWorkerError = [string]$event.message }
  } catch { Add-Log $Line }
}

$addButton.Add_Click({
  $dialog = New-Object System.Windows.Forms.OpenFileDialog
  $dialog.Title = 'Select clothing and accessory images'
  $dialog.Filter = 'Image files|*.png;*.jpg;*.jpeg;*.webp;*.tif;*.tiff;*.avif;*.gif|All files|*.*'
  $dialog.Multiselect = $true
  if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
    foreach ($filename in $dialog.FileNames) { if (-not $sources.Items.Contains($filename)) { [void]$sources.Items.Add($filename) } }
  }
  $dialog.Dispose()
})
$removeButton.Add_Click({ $selected = @($sources.SelectedItems); foreach ($item in $selected) { $sources.Items.Remove($item) } })
$clearButton.Add_Click({ $sources.Items.Clear() })
$folderButton.Add_Click({
  $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description = 'Choose the parent output folder. Each run creates a fresh batch folder.'
  $dialog.ShowNewFolderButton = $true
  if ($outputText.Text) { $dialog.SelectedPath = $outputText.Text }
  if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) { $outputText.Text = $dialog.SelectedPath }
  $dialog.Dispose()
})
$showButton.Add_Click({ if ($script:lastOutput -and (Test-Path -LiteralPath $script:lastOutput -PathType Container)) { Start-Process -FilePath $script:lastOutput } })
$editorButton.Add_Click({ Start-Process -FilePath $editorPath })

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 100
$timer.Add_Tick({
  try {
    if ($script:outputTask -and $script:outputTask.IsCompleted) {
      $line = $script:outputTask.GetAwaiter().GetResult()
      if ($null -eq $line) { $script:outputEnded = $true; $script:outputTask = $null }
      else { Read-WorkerLine $line; $script:outputTask = $script:worker.StandardOutput.ReadLineAsync() }
    }
    if ($script:errorTask -and $script:errorTask.IsCompleted) {
      $line = $script:errorTask.GetAwaiter().GetResult()
      if ($null -eq $line) { $script:errorEnded = $true; $script:errorTask = $null }
      else { Add-Log $line; $script:errorTask = $script:worker.StandardError.ReadLineAsync() }
    }
    if ($script:worker -and $script:worker.HasExited -and $script:outputEnded -and $script:errorEnded) {
      if (-not $script:explorerMode) { $timer.Stop() }
      $code = $script:worker.ExitCode
      if ($code -ne 0 -and -not $script:reportedError) { $statusLabel.Text = "Stopped with exit code $code. See the messages below."; Add-Log $statusLabel.Text }
      $script:worker.Dispose(); $script:worker = $null
      if ($script:requestPath) { Remove-Item -LiteralPath $script:requestPath -Force -ErrorAction SilentlyContinue; $script:requestPath = $null }
      Set-Running $false
      if ($script:explorerJob) { Complete-ExplorerGroup $code }
    }
    if ($script:explorerMode -and -not $script:worker -and -not $script:explorerPaused) { Process-ExplorerQueue }
  } catch { $timer.Stop(); Add-Log $_.Exception.Message; $statusLabel.Text = 'The progress display encountered an error. Wait for the current batch to finish before restarting.' }
})

function Start-ManualRequest($Request, [switch]$KeepLog) {
  try {
    $requestDir = Join-Path ([System.IO.Path]::GetTempPath()) 'GARMENT-ISOLATER-MANUAL'
    [void][System.IO.Directory]::CreateDirectory($requestDir)
    $script:requestPath = Join-Path $requestDir (([Guid]::NewGuid().ToString('N')) + '.json')
    [System.IO.File]::WriteAllText($script:requestPath, ($Request | ConvertTo-Json -Depth 5), (New-Object System.Text.UTF8Encoding($false)))
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $nodePath
    $info.Arguments = (@($runnerPath, '--request', $script:requestPath, '--runtime-dir', $runtimePath) | ForEach-Object { ConvertTo-WindowsArgument ([string]$_) }) -join ' '
    $info.WorkingDirectory = $toolRoot
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $info.StandardErrorEncoding = [System.Text.Encoding]::UTF8
    $script:worker = New-Object System.Diagnostics.Process
    $script:worker.StartInfo = $info
    if (-not $KeepLog) { $log.Clear() }
    $progress.Value = 0; $script:reportedError = $false; $script:outputEnded = $false; $script:errorEnded = $false
    $script:lastWorkerFolder = $null; $script:lastWorkerComplete = $false; $script:lastWorkerError = $null
    Set-Running $true
    $statusLabel.Text = 'Starting. Model loading and large images can take time; the window remains responsive.'
    [void]$script:worker.Start()
    $script:outputTask = $script:worker.StandardOutput.ReadLineAsync()
    $script:errorTask = $script:worker.StandardError.ReadLineAsync()
    $timer.Start()
    return $true
  } catch {
    Add-Log $_.Exception.Message; $statusLabel.Text = 'Could not start. See the message below.'
    if ($script:worker) { $script:worker.Dispose(); $script:worker = $null }
    Set-Running $false
    $script:lastWorkerError = $_.Exception.Message
    return $false
  }
}
function Finish-ExplorerJob([string]$Failure = $null) {
  $job = $script:explorerJob
  $failedGroups = @($job.Groups | Where-Object { $_.Status -ne 'complete' })
  $status = if ($Failure -or $failedGroups.Count) { 'error' } else { 'complete' }
  $receipt = [ordered]@{
    schema='garment-explorer-result-v1'; id=$job.Id; status=$status; request=$job.RequestPath
    started_utc=$job.StartedUtc; completed_utc=[DateTime]::UtcNow.ToString('o')
    selected_count=$job.SelectedCount; unique_count=$job.UniqueCount; duplicate_count=$job.DuplicateCount
    model='u2net'; force_segment=$false; native_size=$true
    groups=@($job.Groups | ForEach-Object { [ordered]@{ output_parent=$_.OutputParent; count=$_.Sources.Count; status=$_.Status; folder=$_.Folder; error=$_.Error } })
    error=$Failure
  }
  try {
    $receiptPath = Write-ExplorerReceipt $script:explorerQueuePath $job.Id $status $receipt
    Add-Log ("Explorer request $status. Receipt: $receiptPath")
    $statusLabel.Text = if ($status -eq 'complete') { "Finished Explorer selection: $($job.UniqueCount) images. Open output folder to review." } else { 'Explorer selection stopped with errors. See the messages and receipt; originals were preserved.' }
  } catch {
    $script:explorerPaused = $true
    Add-Log ("Could not save the Explorer receipt: " + $_.Exception.Message)
    $statusLabel.Text = 'Explorer queue paused. The request was preserved. Close this idle window and inspect its messages before relaunching.'
  }
  $script:explorerJob = $null
}
function Complete-ExplorerGroup([int]$ExitCode) {
  $job = $script:explorerJob
  $group = $job.Groups[$job.GroupIndex]
  $group.Folder = $script:lastWorkerFolder
  if ($ExitCode -eq 0 -and $script:lastWorkerComplete) { $group.Status = 'complete' }
  else {
    $group.Status = 'error'
    $group.Error = if ($script:lastWorkerError) { $script:lastWorkerError } else { "The image worker stopped with exit code $ExitCode without a complete result." }
  }
  $job.GroupIndex++
}
function Process-ExplorerQueue {
  if ($script:worker) { return }
  try {
    if (-not $script:explorerJob) {
      $running = Claim-ExplorerReady $script:explorerQueuePath
      if (-not $running) { return }
      $script:explorerJob = [PSCustomObject]@{ Id=[System.IO.Path]::GetFileName($running).Substring(0,32).ToLowerInvariant(); RequestPath=$running; StartedUtc=[DateTime]::UtcNow.ToString('o'); SelectedCount=0; UniqueCount=0; DuplicateCount=0; Groups=@(); GroupIndex=0 }
      $log.Clear()
      Add-Log ("Explorer selection claimed: $running")
      try {
        $selection = Read-ExplorerSelection $running
        $script:explorerJob.SelectedCount = $selection.SelectedCount
        $script:explorerJob.UniqueCount = $selection.Sources.Count
        $script:explorerJob.DuplicateCount = $selection.DuplicateCount
        $script:explorerJob.Groups = Get-ExplorerGroups $selection.Sources
        Add-Log ("Selected $($selection.Sources.Count) images in $($script:explorerJob.Groups.Count) source folder(s). Results will be saved beside each group of originals.")
        if ($selection.DuplicateCount) { Add-Log ("Repeated paths omitted: $($selection.DuplicateCount).") }
      } catch { Finish-ExplorerJob $_.Exception.Message; return }
    }
    $job = $script:explorerJob
    if ($job.GroupIndex -ge $job.Groups.Count) { Finish-ExplorerJob; return }
    $group = $job.Groups[$job.GroupIndex]
    $sources.Items.Clear()
    foreach ($source in $group.Sources) { [void]$sources.Items.Add($source) }
    $outputText.Text = $group.OutputParent
    $detailedIndex = $modelBox.Items.IndexOf('Detailed - U2NET')
    if ($detailedIndex -lt 0) { $group.Status='error'; $group.Error='The included Detailed U2NET model is missing.'; $job.GroupIndex++; return }
    $modelBox.SelectedIndex = $detailedIndex
    $forceBox.Checked = $false
    Add-Log ("Starting source-folder group $($job.GroupIndex+1) of $($job.Groups.Count): $($group.OutputParent)")
    $group.Status = 'processing'
    if (-not (Start-ManualRequest @{ mode='remove'; sources=$group.Sources.ToArray(); output_parent=$group.OutputParent; model='u2net'; force_segment=$false } -KeepLog)) {
      $group.Status='error'; $group.Error=$script:lastWorkerError; $job.GroupIndex++
    }
  } catch {
    $script:explorerPaused = $true
    Add-Log $_.Exception.Message
    $statusLabel.Text = 'Explorer queue paused. Pending request files were preserved. Close this idle window and inspect its messages before relaunching.'
    if ($script:explorerJob) { Finish-ExplorerJob $_.Exception.Message }
  }
}
$startButton.Add_Click({
  if ($sources.Items.Count -eq 0) { $statusLabel.Text = 'Add at least one image first.'; return }
  if (-not $outputText.Text) { $statusLabel.Text = 'Choose an output folder first.'; return }
  $model = if ([string]$modelBox.SelectedItem -eq 'Detailed - U2NET') { 'u2net' } else { 'u2netp' }
  [void](Start-ManualRequest @{ sources = @($sources.Items | ForEach-Object { [string]$_ }); output_parent = $outputText.Text; model = $model; force_segment = $forceBox.Checked })
})
$applyButton.Add_Click({
  $sourceDialog = New-Object System.Windows.Forms.OpenFileDialog
  $sourceDialog.Title = 'Choose the original image that matches your saved mask'
  $sourceDialog.Filter = 'Image files|*.png;*.jpg;*.jpeg;*.webp;*.tif;*.tiff;*.avif|All files|*.*'
  if ($sourceDialog.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { $sourceDialog.Dispose(); return }
  $originalPath = $sourceDialog.FileName
  $sourceDialog.Dispose()
  $maskDialog = New-Object System.Windows.Forms.OpenFileDialog
  $maskDialog.Title = 'Choose the matching grayscale PNG coverage mask'
  $maskDialog.Filter = 'PNG coverage masks|*.png'
  if ($maskDialog.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { $maskDialog.Dispose(); return }
  $savedMask = $maskDialog.FileName
  $maskDialog.Dispose()
  if (-not $outputText.Text) { $folderButton.PerformClick() }
  if (-not $outputText.Text) { $statusLabel.Text = 'Choose an output folder before applying the saved mask.'; return }
  [void](Start-ManualRequest @{ mode = 'apply_mask'; sources = @($originalPath); mask = $savedMask; output_parent = $outputText.Text })
})
$form.Add_FormClosing({
  param($sender,$eventArgs)
  if (($script:worker -and -not $script:worker.HasExited) -or ($script:explorerMode -and ($script:worker -or $script:explorerJob))) {
    $eventArgs.Cancel = $true
    $statusLabel.Text = 'The batch is still running. Leave this window open until it finishes.'
  }
})
if ($script:explorerMode) {
  Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class GarmentExplorerWindow { [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr window, int state); }'
}
$form.Add_Shown({
  if ($script:explorerMode) {
    # The hidden console launcher supplies SW_HIDE for the first native show.
    # Explicitly show only this progress form after that initial show completes.
    [void][GarmentExplorerWindow]::ShowWindow($form.Handle, 5)
    $timer.Start()
  }
})
if ($ValidateUI) {
  $form.CreateControl()
  Write-Output ("Windows form controls created; default model: " + [string]$modelBox.SelectedItem)
} else {
  [void]$form.ShowDialog()
}
$timer.Dispose()
$form.Dispose()
if ($script:explorerMutexHeld) { $script:explorerMutex.ReleaseMutex() }
if ($script:explorerMutex) { $script:explorerMutex.Dispose() }
