#!/usr/bin/env node
'use strict';
/* Non-destructive wardrobe acquisition and PNG export. Requires sharp >=0.34.
 * JSON manifests supply visually reviewed names and grayscale COVERAGE masks.
 * Sources are never changed. Image outputs are committed without overwriting.
 */
const fs = require('node:fs');
const fsp = fs.promises;
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const HELP_TEXT = `GARMENT ISOLATER asset pipeline

Usage:
  node asset_pipeline.cjs doctor
  node asset_pipeline.cjs inventory FOLDER [--recursive]
  node asset_pipeline.cjs download MANIFEST.json --output-dir ORIGINALS
  node asset_pipeline.cjs export MANIFEST.json --output-dir PNGS [--long-edge N | --scale N]
  node asset_pipeline.cjs verify OUTPUT_FOLDER
  node asset_pipeline.cjs contact-sheet MANIFEST.json --output Review.png

Download manifest: [{"url":"https://example.com/original.jpg","filename":"Red Jacket.jpg"}]
Export manifest: [{"source":"ABSOLUTE_PATH","filename":"Red Jacket.png","mask":"OPTIONAL_ABSOLUTE_MASK_PATH"}]
Contact-sheet manifest: [{"source":"ABSOLUTE_PATH","filename":"Optional display label"}]
For animated/multipage export inputs, set an explicit zero-based "frame" in the row.

Options:
  --runtime-dir DIR       Resolve sharp from DIR/node_modules (all commands).
  --max-input-pixels N    Explicit input ceiling; default 100000000 (verify: 500000000).
  --memory-mb N           Explicit RAM budget (download, export, contact-sheet).
                         Otherwise use 60% of available physical RAM.
  --long-edge N           Enlarge proportionally to this edge; never shrink (export).
  --scale N              Enlarge proportionally by a factor >=1 (export).
  --max-pixels N          Explicit output ceiling; default 500000000 (export).
  --timeout SECONDS      Whole download timeout; default 60 (download).
  --max-bytes N           Source download byte limit; default 536870912 (download).
  --columns N            Review sheet columns, 1-20; default 4 (contact-sheet).
  --cell-edge N          Review thumbnail cell, 64-2048; default 256 (contact-sheet).
  --recursive            Include subfolders only when explicitly selected (inventory).
  -h, --help             Show this help.

Masks must be single-channel 8-bit grayscale at native EXIF-oriented dimensions.
White keeps the garment; black removes it. Coverage multiplies source alpha once.
Names are exact Windows-safe leaf filenames. No suffix is added automatically.
No source is modified and no existing image is overwritten. asset-manifest.json
records hashes and resume state. Use a fresh folder for a changed source or size.
16-bit/HDR export inputs are refused before any precision can be discarded.
Lanczos enlargement changes pixel count, not captured detail. A failed RAM/pixel
preflight never silently lowers the requested size. Commands emit JSON results.
`;
if (require.main === module && process.argv.slice(2).some(value => ['--help','-h'].includes(value))) { process.stdout.write(HELP_TEXT); process.exit(0); }
const runtimeIndex = process.argv.indexOf('--runtime-dir');
let sharp;
try { sharp = runtimeIndex >= 0 ? require(path.join(path.resolve(process.argv[runtimeIndex + 1] || ''), 'node_modules', 'sharp')) : require('sharp'); }
catch (error) { process.stderr.write(JSON.stringify({status:'error',code:'missing_dependency',message:'sharp is unavailable. Run setup_runtime.cjs and supply --runtime-dir with the isolated runtime folder.',reason:error.message})+'\n'); process.exit(2); }
sharp.cache(false);
sharp.concurrency(1);

const VERSION = '1.0.0';
const STATE_NAME = 'asset-manifest.json';
const LOCK_NAME = '.asset-batch.lock';
const DEFAULT_MAX_INPUT_PIXELS = 100000000;
const DEFAULT_MAX_PIXELS = 500000000;
const DEFAULT_MAX_BYTES = 512 * 1024 * 1024;
const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.tif', '.tiff', '.avif', '.heic', '.heif']);
const FORMAT_EXTENSIONS = { jpeg: ['.jpg', '.jpeg'], png: ['.png'], webp: ['.webp'], gif: ['.gif'], tiff: ['.tif', '.tiff'], heif: ['.avif', '.heif', '.heic'] };
const RESERVED = new Set(['CON', 'PRN', 'AUX', 'NUL', 'CONIN$', 'CONOUT$', ...['COM', 'LPT'].flatMap(p => [...'123456789¹²³'].map(n => p + n))]);
const fold = value => value.toLocaleLowerCase('en-US');
class AssetError extends Error {
  constructor(code, message, details = {}) { super(message); this.code = code; this.details = details; }
  toJSON() { return { status: 'error', code: this.code, message: this.message, ...this.details }; }
}
function fail(code, message, details) { throw new AssetError(code, message, details); }
function safeLeaf(value, png = false) {
  if (typeof value !== 'string' || !value || value === '.' || value === '..' || /[<>:"/\\|?*\x00-\x1f\x7f]/.test(value) || /[ .]$/.test(value)) fail('invalid_filename', 'Use an exact Windows-safe leaf filename without folders or a trailing dot/space.', { filename: value });
  if (RESERVED.has(value.split('.')[0].replace(/[ .]+$/, '').toUpperCase()) || value.length > 255) fail('invalid_filename', 'The filename is reserved by Windows or exceeds 255 UTF-16 characters.', { filename: value });
  if ([fold(STATE_NAME), fold(LOCK_NAME)].includes(fold(value)) || fold(value).startsWith('.asset-')) fail('reserved_filename', 'This filename is reserved for batch records.', { filename: value });
  if (png && fold(path.extname(value)) !== '.png') fail('invalid_filename', 'Exported filenames must end in .png.', { filename: value });
  return value;
}
async function absoluteSource(value, field = 'source') {
  if (typeof value !== 'string' || !path.isAbsolute(value)) fail('invalid_source', `${field} must be an absolute existing file path.`, { field, path: value });
  let source;
  try { source = await fsp.realpath(value); if (!(await fsp.stat(source)).isFile()) throw new Error('not a regular file'); }
  catch (error) { fail('missing_source', `${field} does not identify an existing regular file.`, { field, path: value, reason: error.message }); }
  return source;
}
async function sha256(filename) {
  const digest = crypto.createHash('sha256');
  for await (const chunk of fs.createReadStream(filename)) digest.update(chunk);
  return digest.digest('hex');
}
function stableHash(value) { return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex'); }
async function readList(filename) {
  let rows;
  try { rows = JSON.parse((await fsp.readFile(filename, 'utf8')).replace(/^\uFEFF/, '')); }
  catch (error) { fail('invalid_manifest', 'Cannot read the JSON manifest.', { path: filename, reason: error.message }); }
  if (!Array.isArray(rows) || !rows.length || rows.some(row => !row || typeof row !== 'object' || Array.isArray(row))) fail('invalid_manifest', 'The manifest must be a nonempty JSON list of objects.');
  return rows;
}
function positiveInteger(value, label) { if (!Number.isSafeInteger(value) || value <= 0) fail('invalid_limit', `${label} must be a positive safe integer.`, { value }); return value; }
function checkedSize(size, limit, output = false) {
  positiveInteger(limit, output ? 'max-pixels' : 'max-input-pixels');
  if (size.some(side => !Number.isSafeInteger(side) || side <= 0 || side >= 2147483647) || size[0] * size[1] > limit) fail('pixel_limit', 'The dimensions exceed the explicitly configured pixel limit; no size was reduced.', { dimensions: size, pixels: size[0] * size[1], limit, kind: output ? 'output' : 'input' });
}
function targetSize(size, longEdge, scale) {
  if (longEdge !== undefined && scale !== undefined) fail('invalid_resize', 'Choose --long-edge OR --scale.');
  let factor = 1;
  if (longEdge !== undefined) factor = Math.max(1, positiveInteger(longEdge, 'long-edge') / Math.max(...size));
  if (scale !== undefined) { if (!Number.isFinite(scale) || scale < 1) fail('invalid_resize', '--scale must be finite and at least 1; the helper does not shrink assets.'); factor = scale; }
  return size.map(side => Math.max(side, Math.floor(side * factor + 0.5)));
}
function memoryBudget(memoryMb) {
  const available = os.freemem();
  if (memoryMb !== undefined && (!Number.isFinite(memoryMb) || memoryMb <= 0)) fail('invalid_memory_budget', '--memory-mb must be a positive finite number.');
  const chosen = memoryMb === undefined ? Math.floor(available * 0.6) : Math.floor(memoryMb * 1024 * 1024);
  if (chosen > available) fail('memory_budget_unavailable', 'The selected memory budget exceeds currently available physical RAM.', { requested_bytes: chosen, available_bytes: available });
  return chosen;
}
function estimatedMemory(source, target, mask = false) { return 64 * 1024 * 1024 + source[0] * source[1] * (mask ? 20 : 16) + target[0] * target[1] * 32; }
function checkMemory(source, target, budget, mask = false) {
  const estimate = estimatedMemory(source, target, mask), effective = Math.min(budget, Math.floor(os.freemem() * .85));
  if (estimate > effective) fail('insufficient_memory', 'The chosen size exceeds the conservative RAM budget. Choose a smaller size or use more free RAM; no size was reduced.', { source_dimensions: source, requested_dimensions: target, estimated_bytes: estimate, budget_bytes: effective });
  return estimate;
}
function inputOptions(maxInputPixels, extra = {}) { return { limitInputPixels: positiveInteger(maxInputPixels, 'max-input-pixels'), failOn: 'warning', ...extra }; }
// libvips file I/O on Windows needs extended paths once native file names
// exceed MAX_PATH. Keep ordinary paths in Node operations and batch records.
function nativeImagePath(filename) { return process.platform === 'win32' ? path.toNamespacedPath(filename) : filename; }
async function imageMetadata(filename, maxInputPixels = DEFAULT_MAX_INPUT_PIXELS) {
  try {
    const meta = await sharp(nativeImagePath(filename), inputOptions(maxInputPixels)).metadata();
    const size = [meta.width, meta.pageHeight || meta.height];
    checkedSize(size, maxInputPixels);
    const oriented = [5, 6, 7, 8].includes(meta.orientation) ? [size[1], size[0]] : size;
    return { format: meta.format, space: meta.space, depth: meta.depth, channels: meta.channels, dimensions: size, oriented_dimensions: oriented, frames: meta.pages || 1, exif_orientation: meta.orientation || 1, has_icc: Boolean(meta.icc), has_transparency: Boolean(meta.hasAlpha), _meta: meta };
  } catch (error) { if (error instanceof AssetError) throw error; fail('invalid_image', 'The file is not a supported, decodable image.', { path: filename, reason: error.message }); }
}
const publicInfo = info => Object.fromEntries(Object.entries(info).filter(([key]) => key !== '_meta'));
function validateFrame(info, frame, source) {
  if (info.frames > 1 && frame === undefined) fail('frame_required', 'An animated or multipage input needs an explicit zero-based frame number in the export manifest.', { source, frames: info.frames });
  if (frame !== undefined && (!Number.isInteger(frame) || frame < 0 || frame >= info.frames)) fail('invalid_frame', 'frame must select an existing zero-based frame.', { source, frame, frames: info.frames });
}
function validateExportDepth(info, source) {
  if (info.depth !== 'uchar' || (info._meta.bitsPerSample && info._meta.bitsPerSample > 8)) fail('unsupported_bit_depth', 'This helper preserves ordinary 8-bit product images. High-bit-depth/HDR inputs require an explicitly approved conversion workflow; no precision was silently discarded.', { source, depth: info.depth, bits_per_sample: info._meta.bitsPerSample });
  if (!['srgb', 'rgb', 'b-w', 'cmyk', 'lab'].includes(info.space)) fail('unsupported_color_space', 'The source color space requires an explicitly approved conversion workflow.', { source, space: info.space });
}

// PNG iCCP insertion is deliberate: after processing raw RGBA, sharp no longer
// carries the original profile. Attaching that profile without transforming RGB
// preserves compatible source colors exactly at the native cutout stage.
const CRC_TABLE = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ c >>> 1 : c >>> 1; return c >>> 0; });
function crc32(data) { let c = 0xffffffff; for (const byte of data) c = CRC_TABLE[(c ^ byte) & 255] ^ c >>> 8; return (c ^ 0xffffffff) >>> 0; }
function pngChunk(type, data) { const kind = Buffer.from(type, 'ascii'), result = Buffer.alloc(data.length + 12); result.writeUInt32BE(data.length, 0); kind.copy(result, 4); data.copy(result, 8); result.writeUInt32BE(crc32(Buffer.concat([kind, data])), data.length + 8); return result; }
async function attachIcc(filename, profile) {
  if (!profile) return;
  const original = await fsp.readFile(filename);
  if (!original.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) fail('invalid_png', 'The staged export is not PNG.');
  const iccp = pngChunk('iCCP', Buffer.concat([Buffer.from('Source profile\0\0', 'binary'), zlib.deflateSync(profile)]));
  const chunks = [original.subarray(0, 33), iccp];
  let cursor = 33;
  while (cursor < original.length) { const size = original.readUInt32BE(cursor), type = original.toString('ascii', cursor + 4, cursor + 8); if (!['iCCP', 'sRGB'].includes(type)) chunks.push(original.subarray(cursor, cursor + size + 12)); cursor += size + 12; }
  await fsp.writeFile(filename, Buffer.concat(chunks));
}
let srgbProfile;
async function getSrgbProfile() {
  if (!srgbProfile) { const sample = await sharp({ create: { width: 1, height: 1, channels: 3, background: '#ffffff' } }).withIccProfile('srgb').png().toBuffer(); srgbProfile = (await sharp(sample).metadata()).icc; }
  return srgbProfile;
}
async function loadOrientedRgba(source, info, maxInputPixels, frame) {
  validateFrame(info, frame, source); validateExportDepth(info, source);
  const rgbCompatible = ['srgb', 'rgb'].includes(info.space);
  let pipeline = sharp(nativeImagePath(source), inputOptions(maxInputPixels, { ignoreIcc: rgbCompatible || !info.has_icc, page: frame || 0, pages: 1 })).autoOrient();
  const notes = [], profile = rgbCompatible ? info._meta.icc : info.has_icc ? await getSrgbProfile() : null;
  if (!rgbCompatible && info.has_icc) { pipeline = pipeline.withIccProfile('srgb'); notes.push('Embedded non-RGB profile was color-managed to sRGB; the output carries an RGB-compatible sRGB profile.'); }
  else if (!rgbCompatible) notes.push('Source had no ICC profile; standard conversion to sRGB was used.');
  if (info._meta.exif) notes.push('EXIF orientation was applied to pixels. Stale source EXIF metadata was omitted from the PNG.');
  const result = await pipeline.toColourspace('srgb').ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  if (result.info.channels !== 4) fail('invalid_rgba', 'Source conversion did not produce four-channel RGBA.', { channels: result.info.channels });
  return { data: result.data, width: result.info.width, height: result.info.height, profile, notes };
}
async function applyCoverageMask(rgba, filename, maxInputPixels) {
  const info = await imageMetadata(filename, maxInputPixels);
  if (info.frames !== 1 || info.depth !== 'uchar' || info.channels !== 1 || !['b-w', 'grey16'].includes(info.space)) fail('invalid_mask', 'A mask must be a single-channel 8-bit grayscale image: white keeps the garment.', { path: filename, actual: publicInfo(info) });
  if (info.oriented_dimensions[0] !== rgba.width || info.oriented_dimensions[1] !== rgba.height) fail('mask_dimensions', 'Mask dimensions must exactly match the EXIF-oriented source.', { source_dimensions: [rgba.width, rgba.height], mask_dimensions: info.oriented_dimensions });
  const coverage = await sharp(nativeImagePath(filename), inputOptions(maxInputPixels, { ignoreIcc: true })).autoOrient().toColourspace('b-w').raw().toBuffer();
  if (coverage.length !== rgba.width * rgba.height) fail('invalid_mask_buffer', 'Grayscale mask decoding did not produce exactly one coverage value per pixel.', { expected_bytes: rgba.width * rgba.height, actual_bytes: coverage.length });
  for (let pixel = 0; pixel < coverage.length; pixel++) rgba.data[pixel * 4 + 3] = Math.floor(rgba.data[pixel * 4 + 3] * coverage[pixel] / 255);
  return rgba;
}
async function atomicJson(filename, value) {
  const temp = path.join(path.dirname(filename), `.asset-state-${crypto.randomUUID()}.tmp`);
  try { const handle = await fsp.open(temp, 'wx'); try { await handle.writeFile(JSON.stringify(value, null, 2) + '\n'); await handle.sync(); } finally { await handle.close(); } await fsp.rename(temp, filename); }
  finally { await fsp.rm(temp, { force: true }); }
}
async function regularFile(filename) { try { const stat = await fsp.lstat(filename); return stat.isFile() && !stat.isSymbolicLink(); } catch (error) { if (error.code === 'ENOENT') return false; throw error; } }
async function exists(filename) { try { await fsp.lstat(filename); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; } }
async function commitNoClobber(staged, destination) {
  try { await fsp.link(staged, destination); }
  catch (error) {
    if (error.code === 'EEXIST') fail('output_exists', 'The output filename already exists. No image was overwritten.', { path: destination });
    // Some managed/virtual Windows filesystems reject hard links. EXCL copying
    // still prevents clobbering. Pending state retains the staged hash so a
    // partially copied final file can be preserved and recovered on resume.
    if (!['EPERM','EACCES','ENOSYS','ENOTSUP','EXDEV','EINVAL'].includes(error.code)) throw error;
    try { await fsp.copyFile(staged, destination, fs.constants.COPYFILE_EXCL); await syncFile(destination); }
    catch (copyError) { if (copyError.code === 'EEXIST') fail('output_exists', 'The output filename already exists. No image was overwritten.', { path: destination }); throw copyError; }
    if (await sha256(destination) !== await sha256(staged)) fail('copy_verification_failed', 'The exclusive copy did not match its staged SHA-256; both files were preserved.', { path: destination });
  }
  await fsp.unlink(staged);
}
function processAlive(pid) { try { process.kill(pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; } }
async function withBatchLock(directory, callback) {
  const filename = path.join(directory, LOCK_NAME);
  let handle;
  try { handle = await fsp.open(filename, 'wx'); }
  catch (error) {
    if (error.code !== 'EEXIST') throw error;
    let previous; try { previous = JSON.parse(await fsp.readFile(filename, 'utf8')); } catch { fail('batch_locked', 'An unreadable batch lock exists; inspect it before starting another batch.', { lock: filename }); }
    if (!Number.isInteger(previous.pid) || previous.pid <= 0 || processAlive(previous.pid)) fail('batch_running', 'Another batch may still be running. Give it time to finish.', { pid: previous.pid, lock: filename });
    await fsp.unlink(filename); handle = await fsp.open(filename, 'wx');
  }
  try { await handle.writeFile(JSON.stringify({ pid: process.pid, created_utc: new Date().toISOString() })); await handle.sync(); await handle.close(); handle = null; return await callback(); }
  finally { if (handle) await handle.close(); await fsp.rm(filename, { force: true }); }
}
async function readState(directory, operation, settings) {
  const filename = path.join(directory, STATE_NAME);
  if (!await exists(filename)) return { tool: 'garment-isolater', version: VERSION, operation, settings, items: {} };
  let state; try { state = JSON.parse(await fsp.readFile(filename, 'utf8')); } catch (error) { fail('invalid_batch_state', 'The existing batch manifest cannot be read. Preserve and inspect it.', { path: filename, reason: error.message }); }
  if (state.tool !== 'garment-isolater' || state.version !== VERSION || state.operation !== operation || stableHash(state.settings) !== stableHash(settings) || !state.items || typeof state.items !== 'object' || Array.isArray(state.items)) fail('incompatible_batch', 'This output folder belongs to a different operation or resize configuration. Use a fresh output folder.', { path: filename, existing_operation: state.operation, existing_settings: state.settings });
  return state;
}
async function collisionPreflight(directory, planned, state) {
  const existing = new Map(), seen = new Set();
  for (const name of await fsp.readdir(directory)) { const key = fold(name); if (existing.has(key)) fail('ambiguous_existing_names', 'The output folder contains case-insensitive filename collisions.', { filenames: [existing.get(key), name] }); existing.set(key, name); }
  for (const item of planned) {
    const key = fold(item.filename), old = state.items[key];
    if (seen.has(key)) fail('duplicate_filename', 'Two planned filenames collide case-insensitively. Resolve them before running the batch.', { filename: item.filename }); seen.add(key);
    if (old && (old.filename !== item.filename || old.fingerprint !== item.fingerprint)) fail('changed_source_or_name', 'An existing entry has a changed source, mask, frame, URL, or exact filename. Use a fresh output folder.', { filename: item.filename });
    if (existing.has(key)) {
      const filename = path.join(directory, existing.get(key));
      if (!old || existing.get(key) !== item.filename || !await regularFile(filename)) fail('output_exists', 'A nonmatching output filename already exists. No image will be overwritten.', { path: filename });
      if (!['complete', 'pending'].includes(old.status)) fail('output_modified', 'An output has an invalid recorded state. It was preserved; inspect the folder.', { path: filename });
      if (await sha256(filename) !== old.output_sha256) {
        const validStage = old.status === 'pending' && old.commit_strategy === 'exclusive-copy' && typeof old.staged_name === 'string' && /^\.asset-stage-[a-f0-9-]+\.tmp$/.test(old.staged_name);
        const staged = validStage ? path.join(directory, old.staged_name) : null;
        if (!staged || !await regularFile(staged) || await sha256(staged) !== old.output_sha256) fail('output_modified', 'An output no longer matches its recorded SHA-256. It was preserved; inspect it or use a fresh folder.', { path: filename });
      }
    } else if (old && old.status === 'complete') fail('output_missing', 'A completed output is missing. Restore it or use a fresh output folder.', { filename: item.filename });
  }
}
async function resumeItem(directory, item, state) {
  const key = fold(item.filename), old = state.items[key];
  if (!old) return null;
  if (old.status === 'pending') {
    if (typeof old.staged_name !== 'string' || !/^\.asset-stage-[a-f0-9-]+\.tmp$/.test(old.staged_name)) fail('invalid_batch_state', 'The pending staging filename is invalid.', { filename: item.filename });
    const staged = path.join(directory, old.staged_name), destination = path.join(directory, item.filename);
    if (await exists(destination)) {
      if (await sha256(destination) !== old.output_sha256) {
        // Only recorded, pending EXCL copies with a verified original staged
        // file reach this branch. Preserve partial/user-modified bytes first.
        const preserved = path.join(directory, `.asset-interrupted-${crypto.randomUUID()}.tmp`);
        await fsp.copyFile(destination, preserved, fs.constants.COPYFILE_EXCL); await syncFile(preserved);
        if (await sha256(destination) !== await sha256(preserved)) fail('recovery_changed_output', 'The interrupted output changed while preserving it; both files remain.', { path: destination, preserved });
        await fsp.unlink(destination); old.preserved_interrupted_output = preserved;
        await atomicJson(path.join(directory, STATE_NAME), state); await commitNoClobber(staged, destination);
      } else if (await regularFile(staged) && await sha256(staged) === old.output_sha256) await fsp.unlink(staged);
    }
    else if (await regularFile(staged) && await sha256(staged) === old.output_sha256) await commitNoClobber(staged, destination);
    else { delete state.items[key]; await atomicJson(path.join(directory, STATE_NAME), state); return null; }
    old.status = 'complete'; delete old.staged_name; await atomicJson(path.join(directory, STATE_NAME), state);
  }
  return { ...old, resumed: true };
}
async function stagedFile(directory) { const filename = path.join(directory, `.asset-stage-${crypto.randomUUID()}.tmp`); const handle = await fsp.open(filename, 'wx'); await handle.close(); return filename; }
async function registerCommit(directory, item, state, staged, details) {
  const stat = await fsp.stat(staged);
  const record = { filename: item.filename, fingerprint: item.fingerprint, status: 'pending', staged_name: path.basename(staged), commit_strategy: 'exclusive-copy', output_sha256: await sha256(staged), output_bytes: stat.size, ...details };
  state.items[fold(item.filename)] = record; await atomicJson(path.join(directory, STATE_NAME), state);
  await commitNoClobber(staged, path.join(directory, item.filename));
  record.status = 'complete'; delete record.staged_name; await atomicJson(path.join(directory, STATE_NAME), state);
  return { ...record, resumed: false };
}
async function syncFile(filename) { const handle = await fsp.open(filename, 'r+'); try { await handle.sync(); } finally { await handle.close(); } }
async function exportBatch(rows, outputDir, options = {}) {
  const maxInputPixels = options.maxInputPixels ?? DEFAULT_MAX_INPUT_PIXELS, maxPixels = options.maxPixels ?? DEFAULT_MAX_PIXELS, budget = memoryBudget(options.memoryMb);
  const settings = { long_edge: options.longEdge ?? null, scale: options.scale ?? null, max_pixels: maxPixels, max_input_pixels: maxInputPixels };
  const planned = [];
  for (const row of rows) {
    const filename = safeLeaf(row.filename, true), source = await absoluteSource(row.source), info = await imageMetadata(source, maxInputPixels);
    validateFrame(info, row.frame, source); validateExportDepth(info, source);
    const target = targetSize(info.oriented_dimensions, options.longEdge, options.scale); checkedSize(target, maxPixels, true);
    const mask = row.mask ? await absoluteSource(row.mask, 'mask') : null;
    if (mask) { const mi = await imageMetadata(mask, maxInputPixels); if (mi.frames !== 1 || mi.depth !== 'uchar' || mi.channels !== 1 || mi.space !== 'b-w' || stableHash(mi.oriented_dimensions) !== stableHash(info.oriented_dimensions)) fail('invalid_mask', 'A mask must be one single-channel 8-bit grayscale image at the EXIF-oriented source dimensions.', { mask, expected_dimensions: info.oriented_dimensions, actual: publicInfo(mi) }); }
    const estimate = checkMemory(info.oriented_dimensions, target, budget, Boolean(mask));
    const details = { source, source_sha256: await sha256(source), mask, mask_sha256: mask ? await sha256(mask) : null, frame: row.frame ?? null };
    planned.push({ filename, source, mask, info, target, estimate, details, fingerprint: stableHash({ ...details, ...settings }) });
  }
  const directory = path.resolve(outputDir); await fsp.mkdir(directory, { recursive: true });
  return withBatchLock(directory, async () => {
    const state = await readState(directory, 'export', settings), completed = []; await collisionPreflight(directory, planned, state);
    for (const item of planned) {
      const resumed = await resumeItem(directory, item, state); if (resumed) { completed.push(resumed); continue; }
      checkMemory(item.info.oriented_dimensions, item.target, budget, Boolean(item.mask));
      let staged;
      try {
        const rgba = await loadOrientedRgba(item.source, item.info, maxInputPixels, item.details.frame ?? undefined);
        if (item.mask) await applyCoverageMask(rgba, item.mask, maxInputPixels);
        let pipeline = sharp(rgba.data, { raw: { width: rgba.width, height: rgba.height, channels: 4 }, limitInputPixels: maxInputPixels });
        if (item.target[0] !== rgba.width || item.target[1] !== rgba.height) pipeline = pipeline.resize({ width: item.target[0], height: item.target[1], fit: 'fill', kernel: 'lanczos3' });
        staged = await stagedFile(directory); await pipeline.png({ compressionLevel: 6, palette: false }).toFile(nativeImagePath(staged)); await attachIcc(staged, rgba.profile); await syncFile(staged);
        const outputInfo = await imageMetadata(staged, Math.max(maxInputPixels, maxPixels));
        if (outputInfo.format !== 'png' || stableHash(outputInfo.dimensions) !== stableHash(item.target)) fail('invalid_export', 'The staged PNG does not match requested dimensions.', { actual: publicInfo(outputInfo), target: item.target });
        if (await sha256(item.source) !== item.details.source_sha256 || item.mask && await sha256(item.mask) !== item.details.mask_sha256) fail('source_changed_during_export', 'A source or mask changed while processing. No final output was committed.', { filename: item.filename });
        completed.push(await registerCommit(directory, item, state, staged, { ...item.details, source_dimensions: item.info.oriented_dimensions, dimensions: item.target, mode: 'RGBA', notes: rgba.notes, estimated_memory_bytes: item.estimate, mask_semantics: item.mask ? 'coverage; source alpha multiplied once; RGB untouched before resizing' : null }));
      } catch (error) { if (error instanceof AssetError) error.details.completed_count = completed.length; throw error; }
      finally { const record = state.items[fold(item.filename)]; if (staged && await exists(staged) && (!record || record.staged_name !== path.basename(staged))) await fsp.unlink(staged); }
    }
    return { status: 'ok', operation: 'export', output_dir: directory, manifest: path.join(directory, STATE_NAME), count: completed.length, items: completed };
  });
}
function validateUrl(value) { let parsed; try { parsed = new URL(value); } catch { fail('invalid_url', 'A download URL must be a direct HTTP(S) image URL.', { url: value }); } if (typeof value !== 'string' || !['http:', 'https:'].includes(parsed.protocol) || !parsed.hostname || parsed.username || parsed.password || /[\x00-\x1f]/.test(value)) fail('invalid_url', 'Use a direct HTTP(S) image URL without embedded credentials.', { url: value }); return value; }
async function downloadBatch(rows, outputDir, options = {}) {
  const timeout = options.timeout ?? 60, maxBytes = options.maxBytes ?? DEFAULT_MAX_BYTES, maxInputPixels = options.maxInputPixels ?? DEFAULT_MAX_INPUT_PIXELS, budget = memoryBudget(options.memoryMb);
  if (!Number.isFinite(timeout) || timeout <= 0) fail('invalid_timeout', 'timeout must be a positive finite number of seconds.'); positiveInteger(maxBytes, 'max-bytes');
  const settings = { max_input_pixels: maxInputPixels, max_bytes: maxBytes }, planned = [];
  for (const row of rows) { const url = validateUrl(row.url), filename = safeLeaf(row.filename); if (!IMAGE_EXTENSIONS.has(fold(path.extname(filename)))) fail('invalid_filename', 'Original download filenames need an image extension.', { filename }); planned.push({ url, filename, fingerprint: stableHash({ url, filename, ...settings }) }); }
  const directory = path.resolve(outputDir); await fsp.mkdir(directory, { recursive: true });
  return withBatchLock(directory, async () => {
    const state = await readState(directory, 'download', settings), completed = []; await collisionPreflight(directory, planned, state);
    for (const item of planned) {
      const resumed = await resumeItem(directory, item, state); if (resumed) { completed.push(resumed); continue; }
      let staged;
      try {
        const response = await fetch(item.url, { redirect: 'follow', signal: AbortSignal.timeout(Math.ceil(timeout * 1000)), headers: { 'User-Agent': 'GarmentIsolater/1.0', 'Accept': 'image/*', 'Accept-Encoding': 'identity' } });
        if (!response.ok) fail('download_http_error', 'The image server returned an HTTP error.', { url: item.url, http_status: response.status });
        const resolvedUrl = validateUrl(response.url), contentType = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase(), contentLength = response.headers.get('content-length');
        if (contentType.startsWith('text/') || contentType === 'application/xhtml+xml') fail('not_an_image_response', 'The URL returned text/a web page. Obtain the direct original image URL.', { url: item.url, content_type: contentType });
        if (contentLength && /^\d+$/.test(contentLength) && Number(contentLength) > maxBytes) fail('download_too_large', 'The source exceeds the configured download byte limit.', { url: item.url, content_length: Number(contentLength), max_bytes: maxBytes });
        staged = await stagedFile(directory); const handle = await fsp.open(staged, 'w'); let total = 0;
        try { for await (const chunk of response.body) { total += chunk.length; if (total > maxBytes) fail('download_too_large', 'The source exceeds the configured download byte limit.', { url: item.url, max_bytes: maxBytes }); await handle.writeFile(chunk); } await handle.sync(); } finally { await handle.close(); }
        const info = await imageMetadata(staged, maxInputPixels);
        if (!FORMAT_EXTENSIONS[info.format]) fail('unsupported_original_format', 'The direct URL must provide a supported raster image, not a vector/document disguised with an image filename.', { url: item.url, actual_format: info.format });
        checkMemory(info.dimensions, info.dimensions, budget);
        // stats forces complete decoding without retaining a full raw buffer.
        for (let frame = 0; frame < info.frames; frame++) await sharp(nativeImagePath(staged), inputOptions(maxInputPixels, { page: frame, pages: 1 })).stats();
        const extensions = FORMAT_EXTENSIONS[info.format]; if (extensions && !extensions.includes(fold(path.extname(item.filename)))) fail('extension_mismatch', 'The original filename extension does not match the downloaded format. Correct the manifest filename and rerun.', { filename: item.filename, actual_format: info.format, accepted_extensions: extensions });
        completed.push(await registerCommit(directory, item, state, staged, { url: item.url, resolved_url: resolvedUrl, content_type: contentType, source_sha256: await sha256(staged), ...publicInfo(info) }));
      } catch (error) { if (error instanceof AssetError) { error.details.completed_count = completed.length; throw error; } fail('download_failed', 'Download failed. Completed files and the batch manifest were preserved; rerun the same manifest to resume.', { url: item.url, reason: error.message, completed_count: completed.length }); }
      finally { const record = state.items[fold(item.filename)]; if (staged && await exists(staged) && (!record || record.staged_name !== path.basename(staged))) await fsp.unlink(staged); }
    }
    return { status: 'ok', operation: 'download', output_dir: directory, manifest: path.join(directory, STATE_NAME), count: completed.length, items: completed };
  });
}
async function inventory(folder, recursive = false, maxInputPixels = DEFAULT_MAX_INPUT_PIXELS) {
  const directory = path.resolve(folder); let stat; try { stat = await fsp.stat(directory); } catch {} if (!stat || !stat.isDirectory()) fail('invalid_folder', 'Inventory requires an explicit existing folder.', { path: directory });
  const paths = []; async function collect(dir) { for (const entry of await fsp.readdir(dir, { withFileTypes: true })) { const item = path.join(dir, entry.name); if (entry.isSymbolicLink()) continue; if (entry.isDirectory() && recursive) await collect(item); else if (entry.isFile() && IMAGE_EXTENSIONS.has(fold(path.extname(item))) && !fold(entry.name).startsWith('.asset-')) paths.push(item); } } await collect(directory); paths.sort((a,b) => fold(a).localeCompare(fold(b)));
  const items = [];
  for (const filename of paths) { const item = { source: await fsp.realpath(filename), filename: path.basename(filename), bytes: (await fsp.stat(filename)).size, sha256: await sha256(filename) }; try { Object.assign(item, publicInfo(await imageMetadata(filename, maxInputPixels)), { status: 'ok' }); } catch (error) { item.status = 'error'; item.error = error instanceof AssetError ? error.toJSON() : { message: error.message }; } items.push(item); }
  return { status: 'ok', operation: 'inventory', folder: directory, recursive, count: items.length, items };
}
async function verify(directory, maxInputPixels = DEFAULT_MAX_PIXELS) {
  directory = path.resolve(directory); let state; try { state = JSON.parse(await fsp.readFile(path.join(directory, STATE_NAME), 'utf8')); } catch (error) { fail('invalid_batch_state', 'Verification requires a readable asset-manifest.json.', { reason: error.message }); }
  if (state.tool !== 'garment-isolater' || !state.items || typeof state.items !== 'object' || Array.isArray(state.items)) fail('invalid_batch_state', 'This is not a GARMENT ISOLATER batch manifest.');
  const items = [], budget = memoryBudget();
  for (const record of Object.values(state.items)) {
    const filename = path.join(directory, safeLeaf(record.filename)), failures = [];
    if (record.status !== 'complete') failures.push('Incomplete entry; resume the original batch.');
    if (!await regularFile(filename)) failures.push('Output missing or not a regular file.');
    else { if (await sha256(filename) !== record.output_sha256) failures.push('Output SHA-256 changed.'); try { const info = await imageMetadata(filename, maxInputPixels); if (stableHash(info.dimensions) !== stableHash(record.dimensions)) failures.push('Output dimensions differ from manifest.'); checkMemory(info.dimensions, info.dimensions, budget); await sharp(nativeImagePath(filename), inputOptions(maxInputPixels)).stats(); } catch (error) { failures.push(error.message); } }
    for (const field of ['source', 'mask']) if (record[field]) { if (!await regularFile(record[field])) failures.push(`${field} missing.`); else if (await sha256(record[field]) !== record[`${field}_sha256`]) failures.push(`${field} SHA-256 changed.`); }
    items.push({ filename: record.filename, status: failures.length ? 'error' : 'ok', failures });
  }
  return { status: items.every(item => item.status === 'ok') ? 'ok' : 'error', operation: 'verify', count: items.length, items, note: 'Hashes and decoding verify file integrity. Human visual review is required for garment coverage, edges, and descriptive names.' };
}
async function contactSheet(rows, output, options = {}) {
  const columns = options.columns ?? 4, cellEdge = options.cellEdge ?? 256, maxInputPixels = options.maxInputPixels ?? DEFAULT_MAX_INPUT_PIXELS, budget = memoryBudget(options.memoryMb);
  if (!Number.isInteger(columns) || columns < 1 || columns > 20 || !Number.isInteger(cellEdge) || cellEdge < 64 || cellEdge > 2048) fail('invalid_contact_sheet_size', 'Use 1-20 columns and a cell edge between 64 and 2048 pixels.');
  const width = columns * cellEdge, height = Math.ceil(rows.length / columns) * (cellEdge + 48); checkedSize([width,height], DEFAULT_MAX_PIXELS, true); checkMemory([width,height], [width,height], budget);
  const destination = path.resolve(output); safeLeaf(path.basename(destination), true); await fsp.mkdir(path.dirname(destination), { recursive: true });
  if ((await fsp.readdir(path.dirname(destination))).some(name => fold(name) === fold(path.basename(destination)))) fail('output_exists', 'The contact sheet filename already exists. Choose another exact name.', { path: destination });
  const composite = [], escapeXml = text => String(text).replace(/[<>&"']/g, char => ({ '<':'&lt;', '>':'&gt;', '&':'&amp;', '"':'&quot;', "'":'&apos;' }[char]));
  const background = Buffer.from(`<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="checks" width="32" height="32" patternUnits="userSpaceOnUse"><rect width="32" height="32" fill="#ffffff"/><rect width="16" height="16" fill="#dddddd"/><rect x="16" y="16" width="16" height="16" fill="#dddddd"/></pattern></defs><rect width="100%" height="100%" fill="url(#checks)"/></svg>`);
  let labels = '';
  for (let index = 0; index < rows.length; index++) { const source = await absoluteSource(rows[index].source), info = await imageMetadata(source,maxInputPixels); checkMemory(info.oriented_dimensions, [cellEdge,cellEdge], budget - width * height * 4); const thumb = await sharp(nativeImagePath(source), inputOptions(maxInputPixels,{ page: rows[index].frame || 0,pages:1 })).autoOrient().resize({ width: cellEdge - 12,height:cellEdge - 12,fit:'inside' }).png().toBuffer({resolveWithObject:true}); const left = index % columns * cellEdge, top = Math.floor(index / columns) * (cellEdge + 48); composite.push({ input:thumb.data,left:left + Math.floor((cellEdge-thumb.info.width)/2),top:top+Math.floor((cellEdge-thumb.info.height)/2) }); const label = rows[index].filename || path.basename(source); labels += `<rect x="${left}" y="${top+cellEdge}" width="${cellEdge}" height="48" fill="#eeeeee"/><text x="${left+5}" y="${top+cellEdge+17}" font-family="sans-serif" font-size="12" fill="#111111">${escapeXml(label.slice(0,36))}</text><text x="${left+5}" y="${top+cellEdge+34}" font-family="sans-serif" font-size="12" fill="#111111">${escapeXml(label.slice(36,72))}</text>`; }
  composite.push({input:Buffer.from(`<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">${labels}</svg>`),left:0,top:0});
  const staged = await stagedFile(path.dirname(destination)); try { await sharp(background).composite(composite).png().toFile(nativeImagePath(staged)); await commitNoClobber(staged,destination); } finally { await fsp.rm(staged,{force:true}); }
  return {status:'ok',operation:'contact-sheet',output:destination,sha256:await sha256(destination),count:rows.length,dimensions:[width,height]};
}
function parseArgs(argv) {
  const command = argv.shift(), result = { command }, positional = [], accepted = { doctor:[],inventory:['recursive','max-input-pixels'],download:['output-dir','timeout','max-bytes','max-input-pixels','memory-mb'],export:['output-dir','long-edge','scale','max-pixels','max-input-pixels','memory-mb'],verify:['max-input-pixels'], 'contact-sheet':['output','columns','cell-edge','max-input-pixels','memory-mb'] };
  if (!accepted[command]) fail('usage', 'Commands: doctor; inventory FOLDER [--recursive]; download MANIFEST --output-dir DIR; export MANIFEST --output-dir DIR [--long-edge N | --scale N]; verify DIR; contact-sheet MANIFEST --output FILE.png.');
  for (let index=0;index<argv.length;index++) { const value=argv[index]; if (!value.startsWith('--')) { positional.push(value); continue; } const key=value.slice(2); if (!accepted[command].includes(key) && key!=='runtime-dir') fail('usage', `Unknown option --${key}.`); const camel=key.replace(/-([a-z])/g,(_,char)=>char.toUpperCase()); if (key==='recursive') { result[camel]=true; continue; } if (!argv[index+1] || argv[index+1].startsWith('--')) fail('usage', `--${key} needs a value.`); const raw=argv[++index]; result[camel]=['output-dir','output','runtime-dir'].includes(key)?raw:Number(raw); }
  if (positional.length !== (command==='doctor'?0:1)) fail('usage','Supply exactly one folder or JSON manifest for this command.');
  if (['download','export'].includes(command) && !result.outputDir || command==='contact-sheet' && !result.output) fail('usage','Supply the required --output-dir or --output path.');
  result.positional=positional[0]; return result;
}
async function main(argv = process.argv.slice(2)) {
  try {
    if (argv.some(value => ['--help','-h'].includes(value))) { process.stdout.write(HELP_TEXT); return 0; }
    const args=parseArgs([...argv]); let result;
    if (args.command==='doctor') result={status:'ok',node:process.version,sharp:sharp.versions.sharp,platform:process.platform,available_memory_bytes:os.freemem(),default_memory_budget_bytes:Math.floor(os.freemem()*.6),default_max_input_pixels:DEFAULT_MAX_INPUT_PIXELS,default_max_output_pixels:DEFAULT_MAX_PIXELS,readable_formats:Object.entries(sharp.format).filter(([,capability])=>capability.input.file).map(([name])=>name),note:'Storage space does not set safe image dimensions. RAM and decoder limits do. Lanczos enlargement preserves proportions and does not invent new garment detail.'};
    else if (args.command==='inventory') result=await inventory(args.positional,args.recursive,args.maxInputPixels);
    else if (args.command==='download') result=await downloadBatch(await readList(args.positional),args.outputDir,args);
    else if (args.command==='export') result=await exportBatch(await readList(args.positional),args.outputDir,args);
    else if (args.command==='verify') result=await verify(args.positional,args.maxInputPixels);
    else result=await contactSheet(await readList(args.positional),args.output,args);
    process.stdout.write(JSON.stringify(result,null,2)+'\n'); return result.status==='ok'?0:2;
  } catch(error) { process.stderr.write(JSON.stringify(error instanceof AssetError?error.toJSON():{status:'error',code:'operation_failed',message:error.message,note:'Sources and completed outputs were preserved. Inspect asset-manifest.json and rerun the same command to resume.'},null,2)+'\n'); return 2; }
}
module.exports={AssetError,safeLeaf,targetSize,imageMetadata,loadOrientedRgba,applyCoverageMask,sha256,stableHash,exportBatch,downloadBatch,inventory,verify,contactSheet,main,STATE_NAME,DEFAULT_MAX_INPUT_PIXELS,DEFAULT_MAX_PIXELS,estimatedMemory,checkMemory,atomicJson,commitNoClobber,attachIcc,crc32};
if(require.main===module) main().then(code=>{process.exitCode=code;});
