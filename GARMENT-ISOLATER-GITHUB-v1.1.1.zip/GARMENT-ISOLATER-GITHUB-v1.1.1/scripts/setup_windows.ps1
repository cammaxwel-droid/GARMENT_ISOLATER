param([switch]$CheckOnly,[switch]$SkipSmoke)
$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path -LiteralPath (Split-Path $PSScriptRoot -Parent)).ProviderPath
$taskRuntime=Join-Path $taskRoot 'runtime'
$taskState=Join-Path $taskRoot '.setup-state'
$taskNode=Join-Path $taskRuntime 'node.exe'
$taskNpm=Join-Path $taskRuntime 'npm'
$taskArchiveHash='57f71ab3652e797d84acddc79c81cc9ff1c6ddb2a1974cdb83f00fee9bff4c73'
$taskNodeHash='3602f2bb1a10f2cbab4c36886218a33c1ab3db87290e73b033c46c77147d0237'
$taskArchiveUrl='https://nodejs.org/dist/v24.19.0/node-v24.19.0-win-x64.zip'
$taskLock=$null
$taskTranscribing=$false

function Assert-PlainPath([string]$Path) {
  if(Test-Path -LiteralPath $Path){$taskItem=Get-Item -LiteralPath $Path -Force;if($taskItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint){throw "A linked setup path was preserved: $Path"}}
}
function Assert-OwnedStatePath([string]$Path) {
  $taskFull=[System.IO.Path]::GetFullPath($Path)
  $taskPrefix=[System.IO.Path]::GetFullPath($taskState).TrimEnd('\')+'\'
  if(-not $taskFull.StartsWith($taskPrefix,[System.StringComparison]::OrdinalIgnoreCase)){throw 'An internal setup path escaped its owned cache.'}
  Assert-PlainPath $Path
}
function Hash-File([string]$Path){return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Write-NewJson([string]$Path,$Value) {
  $taskBytes=(New-Object System.Text.UTF8Encoding($false)).GetBytes(($Value|ConvertTo-Json -Depth 12))
  $taskPending=$Path+'.pending-'+[guid]::NewGuid().ToString('N')
  $taskFile=[System.IO.File]::Open($taskPending,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
  try{$taskFile.Write($taskBytes,0,$taskBytes.Length);$taskFile.Flush($true)}finally{$taskFile.Dispose()}
  [System.IO.File]::Move($taskPending,$Path)
}
function Test-Node {
  Assert-PlainPath $taskNode
  if(-not(Test-Path -LiteralPath $taskNode -PathType Leaf)){return $false}
  if((Hash-File $taskNode) -ne $taskNodeHash){throw 'Existing runtime\node.exe differs from the pinned release. It was preserved. Extract a fresh source folder.'}
  return $true
}
function Test-Npm {
  if(-not(Test-Path -LiteralPath $taskNpm)){return $false}
  Assert-PlainPath $taskNpm
  $taskMarker=Join-Path $taskNpm '.garment-npm-layout.json'
  if(-not(Test-Path -LiteralPath $taskMarker -PathType Leaf)){throw 'An unrelated runtime\npm folder exists. It was preserved. Extract a fresh source folder.'}
  $taskInfo=Get-Content -LiteralPath $taskMarker -Raw|ConvertFrom-Json
  if($taskInfo.schema -ne 'garment-portable-npm-v1' -or $taskInfo.archive_sha256 -ne $taskArchiveHash){throw 'The portable npm ownership receipt differs. Existing files were preserved.'}
  $taskExpected=New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
  foreach($taskEntry in $taskInfo.files){
    if([System.IO.Path]::IsPathRooted($taskEntry.path) -or $taskEntry.path -match '(^|[\\/])\.\.([\\/]|$)'){throw 'Invalid npm receipt path.'}
    [void]$taskExpected.Add([string]$taskEntry.path)
    $taskFile=Join-Path $taskNpm $taskEntry.path;Assert-PlainPath $taskFile
    if(-not(Test-Path -LiteralPath $taskFile -PathType Leaf) -or (Hash-File $taskFile) -ne $taskEntry.sha256){throw "Portable npm is incomplete or changed: $taskFile. It was preserved."}
  }
  foreach($taskFile in Get-ChildItem -LiteralPath $taskNpm -File -Recurse -Force){
    $taskRelative=$taskFile.FullName.Substring($taskNpm.Length+1)
    if($taskRelative -ne '.garment-npm-layout.json' -and -not $taskExpected.Contains($taskRelative)){throw "An unrelated npm file was preserved: $($taskFile.FullName)"}
  }
  return (Test-Path -LiteralPath (Join-Path $taskNpm 'bin\npm-cli.js') -PathType Leaf)
}
function Invoke-Node([string[]]$NodeArguments){& $taskNode @NodeArguments;if($LASTEXITCODE -ne 0){throw "The portable setup step stopped with exit code $LASTEXITCODE."}}
try {
  if(-not[Environment]::Is64BitOperatingSystem -or -not[Environment]::Is64BitProcess -or $env:PROCESSOR_ARCHITECTURE -ne 'AMD64'){throw 'This setup supports Windows x64. Use the included Windows launcher.'}
  foreach($taskPath in @($taskRuntime,$taskState)){Assert-PlainPath $taskPath}
  $taskPackagePath=Join-Path $taskRuntime 'package.json'
  $taskPackageLock=Join-Path $taskRuntime 'package-lock.json'
  foreach($taskPath in @($taskPackagePath,$taskPackageLock,(Join-Path $taskRoot 'helpers\generate_mask.cjs'))){if(-not(Test-Path -LiteralPath $taskPath -PathType Leaf)){throw "A source-distribution file is missing: $taskPath. Extract the whole ZIP first."}}
  $taskPackage=Get-Content -LiteralPath $taskPackagePath -Raw|ConvertFrom-Json
  if($taskPackage.dependencies.sharp -ne '0.35.5' -or $taskPackage.dependencies.'onnxruntime-node' -ne '1.30.0'){throw 'Dependency versions differ from this source release.'}
  # npm lockfile v3 has an empty-string package key; PS5 ConvertFrom-Json cannot represent it.
  Add-Type -AssemblyName System.Web.Extensions
  $taskJsonSerializer=New-Object System.Web.Script.Serialization.JavaScriptSerializer
  $taskJsonSerializer.MaxJsonLength=16777216
  $taskLockData=$taskJsonSerializer.DeserializeObject([System.IO.File]::ReadAllText($taskPackageLock))
  if(-not($taskLockData -is [System.Collections.IDictionary]) -or -not $taskLockData.ContainsKey('packages') -or -not($taskLockData['packages'] -is [System.Collections.IDictionary])){throw 'The dependency lock has no valid package dictionary. It was preserved.'}
  foreach($taskEntry in $taskLockData['packages'].Values){
    if(-not($taskEntry -is [System.Collections.IDictionary])){throw 'The dependency lock has an invalid package entry. It was preserved.'}
    if($taskEntry.ContainsKey('resolved') -and $taskEntry['resolved'] -and -not([string]$taskEntry['resolved']).StartsWith('https://registry.npmjs.org/',[System.StringComparison]::Ordinal)){throw 'The dependency lock contains a non-public-registry source. It was preserved.'}
  }
  $taskLockHash=Hash-File $taskPackageLock
  if(Test-Path -LiteralPath (Join-Path $taskRuntime '.npmrc')){throw 'An unrelated runtime\.npmrc was preserved. Extract a fresh source folder to use isolated setup.'}
  # Isolate only this setup process; never read user npm credentials or Node startup hooks.
  foreach($taskVariable in @(Get-ChildItem Env:|Where-Object {$_.Name -match '^(npm_config_|npm_token$|npm_auth_token$|node_auth_token$|node_options$|node_path$)'})){[Environment]::SetEnvironmentVariable($taskVariable.Name,$null,'Process')}
  $env:PATH=$taskRuntime+';'+$env:PATH
  if($CheckOnly){
    Write-Host 'Checking existing portable files without downloading or changing them...'
    if(-not(Test-Node) -or -not(Test-Npm)){throw 'Portable Node/npm is missing. Run Setup Windows.cmd once while connected to the internet.'}
    $taskArguments=@((Join-Path $PSScriptRoot 'setup_models.cjs'),'--root',$taskRoot,'--check-only');if($SkipSmoke){$taskArguments+='--skip-smoke'}
    Invoke-Node $taskArguments
    exit 0
  }
  if(Test-Path -LiteralPath $taskState){
    $taskOwnerPath=Join-Path $taskState 'owner.json'
    if(-not(Test-Path -LiteralPath $taskOwnerPath -PathType Leaf) -or (Get-Content -LiteralPath $taskOwnerPath -Raw|ConvertFrom-Json).schema -ne 'garment-windows-setup-state-v1'){throw 'An unrelated .setup-state folder exists. It was preserved. Extract a fresh source folder.'}
  }else{[void][System.IO.Directory]::CreateDirectory($taskState);Write-NewJson (Join-Path $taskState 'owner.json') @{schema='garment-windows-setup-state-v1';product='GARMENT ISOLATER';node_archive_sha256=$taskArchiveHash}}
  $taskLock=[System.IO.File]::Open((Join-Path $taskState 'setup.lock'),[System.IO.FileMode]::OpenOrCreate,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
  $taskLogDir=Join-Path $taskState 'logs';Assert-OwnedStatePath $taskLogDir;[void][System.IO.Directory]::CreateDirectory($taskLogDir)
  $taskLog=Join-Path $taskLogDir ('setup-'+[guid]::NewGuid().ToString('N')+'.log')
  try{[void](Start-Transcript -LiteralPath $taskLog);$taskTranscribing=$true}catch{}
  Write-Host "GARMENT ISOLATER first setup. Local folder: $taskRoot"
  Write-Host 'Verified files are reused on later runs. Downloads and caches stay in this tool folder.'
  $taskHasNode=Test-Node;$taskHasNpm=Test-Npm
  if(-not $taskHasNode -or -not $taskHasNpm){
    $taskZip=Join-Path $taskState 'node-v24.19.0-win-x64.zip';Assert-OwnedStatePath $taskZip
    if((Test-Path -LiteralPath $taskZip) -and (Hash-File $taskZip) -ne $taskArchiveHash){$taskBad=Join-Path $taskState ('node-invalid-'+[guid]::NewGuid().ToString('N')+'.zip');Assert-OwnedStatePath $taskBad;[System.IO.File]::Move($taskZip,$taskBad);Write-Host 'An invalid owned Node archive was quarantined.'}
    if(-not(Test-Path -LiteralPath $taskZip)){
      $taskDownload=Join-Path $taskState ('node-download-'+[guid]::NewGuid().ToString('N')+'.partial');Assert-OwnedStatePath $taskDownload
      Write-Host 'Downloading official Node 24.19.0 for Windows x64...'
      [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
      $taskPreviousProgress=$ProgressPreference
      try{$ProgressPreference='SilentlyContinue';Invoke-WebRequest -Uri $taskArchiveUrl -OutFile $taskDownload -UseBasicParsing}finally{$ProgressPreference=$taskPreviousProgress}
      if((Hash-File $taskDownload) -ne $taskArchiveHash){throw "Node archive SHA-256 did not match. The unverified download remains in the owned cache: $taskDownload"}
      [System.IO.File]::Move($taskDownload,$taskZip)
    }
    Write-Host 'Node archive verified. Preparing its portable layout...'
    $taskExtract=Join-Path $taskState ('node-unpack-'+[guid]::NewGuid().ToString('N'));Assert-OwnedStatePath $taskExtract
    Expand-Archive -LiteralPath $taskZip -DestinationPath $taskExtract
    $taskDistribution=Join-Path $taskExtract 'node-v24.19.0-win-x64'
    $taskExtractedNode=Join-Path $taskDistribution 'node.exe'
    if((Hash-File $taskExtractedNode) -ne $taskNodeHash){throw 'The extracted Node executable did not match its independent SHA-256 pin.'}
    if(-not $taskHasNode){$taskTemporaryNode=Join-Path $taskRuntime ('.node-'+[guid]::NewGuid().ToString('N')+'.partial');[System.IO.File]::Copy($taskExtractedNode,$taskTemporaryNode,$false);[System.IO.File]::Move($taskTemporaryNode,$taskNode)}
    if(-not $taskHasNpm){
      $taskExtractedNpm=Join-Path $taskDistribution 'node_modules\npm'
      if(-not(Test-Path -LiteralPath (Join-Path $taskExtractedNpm 'bin\npm-cli.js') -PathType Leaf)){throw 'The verified Node archive lacks its npm CLI.'}
      $taskNpmFiles=@(foreach($taskFile in Get-ChildItem -LiteralPath $taskExtractedNpm -File -Recurse -Force){@{path=$taskFile.FullName.Substring($taskExtractedNpm.Length+1);sha256=Hash-File $taskFile.FullName}})
      Write-NewJson (Join-Path $taskExtractedNpm '.garment-npm-layout.json') @{schema='garment-portable-npm-v1';archive_sha256=$taskArchiveHash;files=$taskNpmFiles}
      Assert-OwnedStatePath $taskExtractedNpm
      [System.IO.Directory]::Move($taskExtractedNpm,$taskNpm)
    }
  }
  Write-Host 'Installing pinned image libraries with an isolated npm cache/config...'
  $taskModules=Join-Path $taskRuntime 'node_modules';Assert-PlainPath $taskModules
  $taskIntent=Join-Path $taskState 'dependencies.intent.json'
  if(Test-Path -LiteralPath $taskIntent){$taskIntentInfo=Get-Content -LiteralPath $taskIntent -Raw|ConvertFrom-Json;if($taskIntentInfo.schema -ne 'garment-owned-node-modules-v1' -or $taskIntentInfo.lock_sha256 -ne $taskLockHash){throw 'Dependency setup ownership/version differs. Existing modules were preserved.'}}
  else{if(Test-Path -LiteralPath $taskModules){throw 'An unrelated runtime\node_modules folder exists. It was preserved. Extract a fresh source folder.'};Write-NewJson $taskIntent @{schema='garment-owned-node-modules-v1';lock_sha256=$taskLockHash}}
  $taskReady=Join-Path $taskState 'dependencies.ready.json'
  $taskDependenciesReady=$false
  if(Test-Path -LiteralPath $taskReady){$taskReadyInfo=Get-Content -LiteralPath $taskReady -Raw|ConvertFrom-Json;$taskDependenciesReady=($taskReadyInfo.lock_sha256 -eq $taskLockHash -and (Test-Path -LiteralPath (Join-Path $taskModules 'sharp\package.json')) -and (Test-Path -LiteralPath (Join-Path $taskModules 'onnxruntime-node\package.json')))}
  if(-not $taskDependenciesReady){
    $taskCache=Join-Path $taskState 'npm-cache';Assert-OwnedStatePath $taskCache
    $taskUserConfig=Join-Path $taskState 'npm-user.npmrc';$taskGlobalConfig=Join-Path $taskState 'npm-global.npmrc'
    foreach($taskConfig in @($taskUserConfig,$taskGlobalConfig)){Assert-OwnedStatePath $taskConfig;if(-not(Test-Path -LiteralPath $taskConfig)){[System.IO.File]::WriteAllText($taskConfig,'',(New-Object System.Text.UTF8Encoding($false)))}elseif((Get-Item -LiteralPath $taskConfig).Length -ne 0){throw 'An isolated npm config was modified. It was preserved.'}}
    Push-Location -LiteralPath $taskRuntime
    try{Invoke-Node @((Join-Path $taskNpm 'bin\npm-cli.js'),'ci','--prefix',$taskRuntime,'--cache',$taskCache,'--userconfig',$taskUserConfig,'--globalconfig',$taskGlobalConfig,'--registry','https://registry.npmjs.org/','--ignore-scripts','--include=optional','--no-audit','--no-fund')}finally{Pop-Location}
    if(-not(Test-Path -LiteralPath $taskReady)){Write-NewJson $taskReady @{schema='garment-pinned-dependencies-ready-v1';lock_sha256=$taskLockHash;sharp='0.35.5';onnxruntime_node='1.30.0'}}
  }else{Write-Host 'Pinned image-library install is already recorded; checking the runtime below.'}
  $taskArguments=@((Join-Path $PSScriptRoot 'setup_models.cjs'),'--root',$taskRoot);if($SkipSmoke){$taskArguments+='--skip-smoke'}
  Invoke-Node $taskArguments
  Write-Host 'Setup complete. No registry or Windows security settings were changed.'
  Write-Host "Setup log: $taskLog"
}catch{
  $taskFailure=$_
  Write-Host ''
  Write-Host ('SETUP ERROR: '+$taskFailure.Exception.Message) -ForegroundColor Red
  Write-Host ('Error type: '+$taskFailure.Exception.GetType().FullName)
  if($taskFailure.InvocationInfo){Write-Host ('Script location: '+$taskFailure.InvocationInfo.ScriptName+':'+$taskFailure.InvocationInfo.ScriptLineNumber);if($taskFailure.InvocationInfo.PositionMessage){Write-Host $taskFailure.InvocationInfo.PositionMessage}}
  if($taskFailure.ScriptStackTrace){Write-Host ('Script stack: '+$taskFailure.ScriptStackTrace)}
  if($taskFailure.Exception.InnerException){Write-Host ('Inner error: '+$taskFailure.Exception.InnerException.Message)}
  if($taskLog){Write-Host ('Setup log: '+$taskLog)}
  Write-Host 'Verified downloads remain in the local cache. Retry only after the cause is resolved.'
  exit 1
}
finally{if($taskLock){$taskLock.Dispose()};if($taskTranscribing){try{[void](Stop-Transcript)}catch{}}}
