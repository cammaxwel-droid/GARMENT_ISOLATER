'use strict';
// Output diagnostics only. No alternate write process, security changes or fallback destination.
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');

class OutputFolderError extends Error {
  constructor(message,details={}) {super(message);this.name='OutputFolderError';Object.assign(this,details);}
}
async function parentStatus(parent,io) {
  try{return (await io.stat(parent)).isDirectory()?'present':'not-a-folder';}
  catch(error){return error.code==='ENOENT'?'missing':'unknown';}
}
async function outputFailure(parent,error,operation,io=fs) {
  const status=await parentStatus(parent,io);
  const windowsCode=error.code||'unknown';
  let message;
  if(status==='missing'||status==='not-a-folder') message=`The selected output folder is missing, moved, or is not a folder: ${parent}. Choose the folder again. No images were processed.`;
  else if(status==='present') message=`Cannot write in the selected output folder: ${parent}. The folder still exists, but this tool could not create its output (Windows error ${windowsCode}). No images were processed. Windows Security may have blocked this copy through Controlled folder access. Check Protection history, then review Virus & threat protection > Manage ransomware protection > Allow an app through Controlled folder access for this exact verified application: ${process.execPath}. The tool does not change Windows Security settings.`;
  else message=`The selected output folder could not be checked: ${parent} (Windows error ${windowsCode}). No images were processed. Check that the folder is available and writable.`;
  return new OutputFolderError(message,{code:'output_folder_unwritable',windows_code:windowsCode,output_parent:parent,parent_status:status,operation,application:process.execPath,cause:error});
}

async function resolveWritableOutputParent(selected,io=fs) {
  if(typeof selected!=='string'||!path.isAbsolute(selected)) throw new OutputFolderError('Choose an existing output folder. No images were processed.',{code:'invalid_output_folder'});
  let parent;
  try {
    parent=await io.realpath(selected);
    if(!(await io.stat(parent)).isDirectory()) throw Object.assign(new Error('Not a folder'),{code:'ENOTDIR'});
  } catch(error) {throw await outputFailure(selected,error,'locate-output',io);}
  const probe=path.join(parent,`.garment-write-check-${crypto.randomUUID()}`),filename=path.join(probe,'write-check.tmp');
  let directoryCreated=false,fileCreated=false,file=null,failure=null,cleanupFailure=null;
  try {
    await io.mkdir(probe,{recursive:false});directoryCreated=true;
    file=await io.open(filename,'wx');fileCreated=true;
    await file.writeFile(Buffer.from('GARMENT ISOLATER output check\n','utf8'));
    await file.close();file=null;
  } catch(error) {failure=error;}
  finally {
    if(file) await file.close().catch(()=>{});
    // Only the exact UUID-named probe objects created by this call are removed.
    if(fileCreated) try{await io.unlink(filename);}catch(error){cleanupFailure=error;}
    if(directoryCreated) try{await io.rmdir(probe);}catch(error){cleanupFailure=cleanupFailure||error;}
  }
  if(failure) {
    const error=await outputFailure(parent,failure,'output-write-preflight',io);
    if(cleanupFailure){error.probe_folder=probe;error.message+=` The temporary write-check folder could not be removed: ${probe}.`;}
    throw error;
  }
  if(cleanupFailure) throw new OutputFolderError(`The output write check succeeded, but its temporary check folder could not be removed: ${probe}. No images were processed. Check the folder before starting again.`,{code:'output_probe_cleanup_failed',windows_code:cleanupFailure.code,probe_folder:probe,output_parent:parent,operation:'output-write-preflight',cause:cleanupFailure});
  return parent;
}

async function createBatchFolder(parent,folder,io=fs) {
  if(path.dirname(path.resolve(folder))!==path.resolve(parent)) throw new OutputFolderError('The batch destination must be directly inside the chosen output folder.',{code:'invalid_batch_destination'});
  try{await io.mkdir(folder,{recursive:false});}
  catch(error){
    if(error.code==='EEXIST') throw new OutputFolderError(`The new batch folder already exists: ${folder}. Existing files were preserved; start again to create a fresh batch.`,{code:'output_batch_exists',output_parent:parent,operation:'create-output'});
    throw await outputFailure(parent,error,'create-output',io);
  }
}
module.exports={OutputFolderError,resolveWritableOutputParent,createBatchFolder,outputFailure,parentStatus};
