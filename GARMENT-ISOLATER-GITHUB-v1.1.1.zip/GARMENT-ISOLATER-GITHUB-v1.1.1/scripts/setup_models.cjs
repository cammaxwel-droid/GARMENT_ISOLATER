'use strict';
const fs=require('node:fs/promises');
const nativeFs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawnSync}=require('node:child_process');
const {createRequire}=require('node:module');
const PINS={u2net:'8d10d2f3bb75ae3b6d527c77944fc5e7dcd94b29809d47a739a7a728a912b491',u2netp:'309c8469258dda742793dce0ebea8e6dd393174f89934733ecc8b14c76f4ddd8'};
async function sha(file){const h=crypto.createHash('sha256');for await(const b of nativeFs.createReadStream(file))h.update(b);return h.digest('hex');}
async function exists(file){try{await fs.lstat(file);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
function inside(root,file){const relative=path.relative(root,file);if(relative==='..'||relative.startsWith('..'+path.sep)||path.isAbsolute(relative))throw new Error('Setup path escaped the extracted tool folder.');}
async function plain(file){const s=await fs.lstat(file);if(s.isSymbolicLink())throw new Error('Setup will not follow a linked file or directory: '+file);return s;}
function psLiteral(s){return "'"+s.replace(/'/g,"''")+"'";}
function publishWindows(source,target){
  // File.Move is a same-volume, no-replacement publication on Windows.
  const code='[System.IO.File]::Move('+psLiteral(source)+','+psLiteral(target)+')';
  const exe=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
  const r=spawnSync(exe,['-NoLogo','-NoProfile','-NonInteractive','-WindowStyle','Hidden','-EncodedCommand',Buffer.from(code,'utf16le').toString('base64')],{windowsHide:true,encoding:'utf8'});
  if(r.error)throw r.error;if(r.status!==0)throw new Error('Could not publish verified model without replacing a file: '+(r.stderr||r.stdout).trim());
}
async function verifyDependencies(runtime){
  for(const [name,version]of [['sharp','0.35.5'],['onnxruntime-node','1.30.0']]){
    const p=JSON.parse(await fs.readFile(path.join(runtime,'node_modules',name,'package.json'),'utf8'));
    if(p.version!==version)throw new Error(name+' does not match the pinned version '+version);
  }
}
async function smoke(runtime){
  const req=createRequire(path.join(runtime,'package.json'));
  const sharp=req('sharp');sharp.concurrency(1);sharp.cache(false);
  const ort=req('onnxruntime-node');if(typeof ort.InferenceSession?.create!=='function')throw new Error('ONNX Runtime could not load its native CPU binding.');
  const pixel=Buffer.from([17,29,43,255]);
  const png=await sharp(pixel,{raw:{width:1,height:1,channels:4}}).png().toBuffer();
  const decoded=await sharp(png).ensureAlpha().raw().toBuffer();
  if(!decoded.equals(pixel))throw new Error('The portable image runtime failed its in-memory PNG round trip.');
  console.log('Portable Sharp and ONNX Runtime loaded; the PNG smoke check passed.');
}
async function main(){
  const args=process.argv.slice(2);let root=path.resolve(__dirname,'..'),check=false,skip=false;
  for(let n=0;n<args.length;n++){
    if(args[n]==='--root'&&args[n+1])root=path.resolve(args[++n]);
    else if(args[n]==='--check-only')check=true;
    else if(args[n]==='--skip-smoke')skip=true;
    else throw new Error('Use --root TOOL_FOLDER [--check-only] [--skip-smoke].');
  }
  if(process.platform!=='win32'||process.arch!=='x64'||process.version!=='v24.19.0')throw new Error('Run Setup Windows.cmd with its verified Windows x64 Node 24.19.0 runtime.');
  const runtime=path.join(root,'runtime'),models=path.join(root,'models'),state=path.join(root,'.setup-state'),cache=path.join(state,'models-cache');
  inside(root,models);inside(root,cache);
  await verifyDependencies(runtime);
  const helper=require(path.join(root,'helpers','generate_mask.cjs'));
  if(!check){
    const owner=JSON.parse(await fs.readFile(path.join(state,'owner.json'),'utf8'));
    if(owner.schema!=='garment-windows-setup-state-v1')throw new Error('The local setup cache has no valid ownership marker.');
    if(await exists(models)){const s=await plain(models);if(!s.isDirectory())throw new Error('models must be a directory.');}else await fs.mkdir(models);
    if(await exists(cache))await plain(cache);else await fs.mkdir(cache);
  }
  for(const [name,pin]of Object.entries(PINS)){
    const destination=path.join(models,name+'.onnx');
    if(await exists(destination)){
      await plain(destination);await helper.modelFile(name,models,false);
      if(await sha(destination)!==pin)throw new Error('Existing '+name+' has an unexpected SHA-256. It was preserved.');
      console.log(name+': existing model verified.');continue;
    }
    if(check)throw new Error(name+' is missing. Run Setup Windows.cmd once while connected to the internet.');
    const modelCache=path.join(cache,name+'-'+pin.slice(0,12)),marker=path.join(modelCache,'owner.json');
    if(await exists(modelCache)){
      await plain(modelCache);const m=JSON.parse(await fs.readFile(marker,'utf8'));
      if(m.schema!=='garment-model-cache-v1'||m.sha256!==pin)throw new Error('Unrelated model cache was preserved: '+modelCache);
    }else{await fs.mkdir(modelCache);await fs.writeFile(marker,JSON.stringify({schema:'garment-model-cache-v1',model:name,sha256:pin}),{flag:'wx'});}
    const cached=path.join(modelCache,name+'.onnx');
    if(await exists(cached)){
      await plain(cached);let valid=false;try{await helper.modelFile(name,modelCache,false);valid=await sha(cached)===pin;}catch{}
      if(!valid){const quarantine=path.join(modelCache,name+'.invalid-'+crypto.randomUUID()+'.onnx');await fs.rename(cached,quarantine);console.log(name+': incomplete/corrupt owned cache quarantined; downloading again.');}
    }
    console.log(name+': preparing the pinned offline model. Please wait.');
    const prepared=await helper.modelFile(name,modelCache,true);
    if(await sha(prepared)!==pin){await fs.rename(prepared,path.join(modelCache,name+'.invalid-'+crypto.randomUUID()+'.onnx'));throw new Error(name+' SHA-256 did not match; the download was quarantined.');}
    const temporary=path.join(models,'.'+name+'-'+crypto.randomUUID()+'.verified.partial');
    await fs.copyFile(prepared,temporary,nativeFs.constants.COPYFILE_EXCL);
    const handle=await fs.open(temporary,'r+');try{await handle.sync();}finally{await handle.close();}
    if(await sha(temporary)!==pin)throw new Error('Verified model copy changed before publication: '+temporary);
    publishWindows(temporary,destination);
    console.log(name+': verified and ready for offline use.');
  }
  if(!skip)await smoke(runtime);
  console.log(check?'READY: portable runtime and both pinned models are available offline.':'READY: setup finished. You can now open Background Remover or Mask Editor.');
}
main().catch(error=>{console.error('Setup error: '+error.message);process.exitCode=1;});
