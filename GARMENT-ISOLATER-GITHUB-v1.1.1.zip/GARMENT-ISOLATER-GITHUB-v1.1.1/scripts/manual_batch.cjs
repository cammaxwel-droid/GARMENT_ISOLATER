#!/usr/bin/env node
'use strict';
// Offline manual batch runner. Every output is created in a new batch folder.
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {resolveWritableOutputParent,createBatchFolder}=require('./output_paths.cjs');

function optionsFrom(argv) {
  const result={};
  for(let index=0;index<argv.length;index++) {
    const name=argv[index];
    if(!['--request','--runtime-dir','--model-dir','--helpers-dir'].includes(name)||!argv[index+1]) throw new Error('Use --request REQUEST.json --runtime-dir RUNTIME [--model-dir MODELS] [--helpers-dir HELPERS]');
    result[name.slice(2)]=path.resolve(argv[++index]);
  }
  if(!result.request||!result['runtime-dir']) throw new Error('--request and --runtime-dir are required');
  return result;
}

function emit(event) {process.stdout.write(JSON.stringify(event)+'\n');}
function batchTimestamp() {
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Australia/Sydney',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date()).map(part=>[part.type,part.value]));
  return `${parts.year}${parts.month}${parts.day}_${parts.hour}${parts.minute}${parts.second}`;
}
function messageFrom(error) {return error.message+(error.details?.reason?' '+error.details.reason:'');}
function runTool(filename,args) {
  return new Promise((resolve,reject)=>{
    const child=spawn(process.execPath,[filename,...args],{windowsHide:true,stdio:['ignore','pipe','pipe']});
    let output='',errors='';
    child.stdout.setEncoding('utf8');child.stderr.setEncoding('utf8');
    child.stdout.on('data',chunk=>{output+=chunk;});
    child.stderr.on('data',chunk=>{errors=(errors+chunk).slice(-12000);});
    child.on('error',reject);
    child.on('close',code=>{
      if(code!==0) {
        let reason=errors.trim()||output.trim()||`Image helper stopped with exit code ${code}`;
        try{const detail=JSON.parse(reason);reason=detail.message+(detail.reason?' '+detail.reason:'');}catch{}
        reject(new Error(reason));return;
      }
      try{resolve(JSON.parse(output));}catch{reject(new Error('The image helper did not return a readable result.'));}
    });
  });
}

async function execute(options) {
  const packageRoot=path.resolve(__dirname,'..');
  const runtime=options['runtime-dir'];
  const helpers=options['helpers-dir']||path.join(packageRoot,'helpers');
  const models=options['model-dir']||path.join(packageRoot,'models');
  // The unchanged asset helper resolves its dependency from this documented CLI argument.
  if(!process.argv.includes('--runtime-dir')) process.argv.push('--runtime-dir',runtime);
  const core=require(path.join(helpers,'asset_pipeline.cjs'));
  const remover=require(path.join(helpers,'generate_mask.cjs'));
  const request=JSON.parse((await fs.readFile(options.request,'utf8')).replace(/^\uFEFF/,''));
  if(!request||!Array.isArray(request.sources)||!request.sources.length) throw new Error('Select at least one source image.');
  if(typeof request.output_parent!=='string'||!path.isAbsolute(request.output_parent)) throw new Error('Choose an existing output folder.');
  const parent=await resolveWritableOutputParent(request.output_parent);
  const model=request.model||'u2net';
  const applySavedMask=request.mode==='apply_mask';
  if(request.mode&&!['remove','apply_mask'].includes(request.mode)) throw new Error('Unknown manual processing mode.');
  if(!['u2net','u2netp'].includes(model)) throw new Error('Choose the included Detailed or Quick model.');
  const names=new Map(),sources=[];
  for(const supplied of request.sources) {
    if(typeof supplied!=='string'||!path.isAbsolute(supplied)) throw new Error('Every selected image must have an absolute path.');
    const source=await fs.realpath(supplied);
    if(!(await fs.stat(source)).isFile()) throw new Error(`Source is not a regular file: ${supplied}`);
    const filename=path.parse(source).name+'.png';
    core.safeLeaf(filename,true);
    const folded=filename.toLocaleLowerCase('en-US');
    if(names.has(folded)) throw new Error(`Two selected images would both save as ${filename}. Choose one of them or give the source files distinct names before starting.`);
    names.set(folded,source);
    sources.push({source,filename,source_sha256:await core.sha256(source)});
  }
  let providedMask=null,providedMaskInfo=null;
  if(applySavedMask) {
    if(sources.length!==1||typeof request.mask!=='string'||!path.isAbsolute(request.mask)) throw new Error('Apply saved mask requires one original image and one matching mask.');
    providedMask=await fs.realpath(request.mask);
    if(!(await fs.stat(providedMask)).isFile()) throw new Error('The saved mask is not a regular file.');
    providedMaskInfo=await core.imageMetadata(providedMask);
    const sourceInfo=await core.imageMetadata(sources[0].source);
    if(providedMaskInfo.frames!==1||providedMaskInfo.depth!=='uchar'||providedMaskInfo.channels!==1||providedMaskInfo.space!=='b-w') throw new Error('Choose an 8-bit one-channel grayscale coverage mask exported by the mask editor.');
    if(providedMaskInfo.oriented_dimensions[0]!==sourceInfo.oriented_dimensions[0]||providedMaskInfo.oriented_dimensions[1]!==sourceInfo.oriented_dimensions[1]) throw new Error('The saved mask dimensions must match the original image after orientation. No image will be resized.');
  } else {
    // This helper never enables a model download. Verify the included weights before creating outputs.
    await remover.modelFile(model,models,false);
  }
  const folder=path.join(parent,`GARMENT_BATCH_${batchTimestamp()}_${crypto.randomBytes(3).toString('hex')}`);
  await createBatchFolder(parent,folder);
  const sourceFolder=path.join(folder,'Sources PNG'),maskFolder=path.join(folder,'Masks'),cutoutFolder=path.join(folder,'Cutouts');
  const reportPath=path.join(folder,'batch-report.json');
  const sourceManifest=path.join(folder,'source-export.json'),cutoutManifest=path.join(folder,'cutout-export.json');
  const report={tool:'GARMENT ISOLATER manual tools',version:'1.0.1',status:'processing',mode:applySavedMask?'apply_mask':'remove',model:applySavedMask?null:model,force_segmentation:!applySavedMask&&Boolean(request.force_segment),native_size:true,source_folder:sourceFolder,mask_folder:maskFolder,cutout_folder:cutoutFolder,items:sources.map(row=>({...row}))};
  const total=sources.length*3;
  let completed=0;
  await core.atomicJson(reportPath,report);
  emit({kind:'batch',folder,message:`New output batch: ${folder}`});
  try {
    emit({kind:'progress',completed,total,message:`Preparing ${sources.length} source PNG${sources.length===1?'':'s'} at original oriented size. Please wait.`});
    await fs.writeFile(sourceManifest,JSON.stringify(sources.map(({source,filename})=>({source,filename})),null,2),{flag:'wx'});
    await runTool(path.join(helpers,'asset_pipeline.cjs'),['export',sourceManifest,'--output-dir',sourceFolder,'--runtime-dir',runtime]);
    completed=sources.length;
    for(let index=0;index<sources.length;index++) {
      const row=sources[index],mask=path.join(maskFolder,row.filename);
      emit({kind:'progress',completed,total,message:applySavedMask?`Applying your saved coverage mask: ${row.filename}`:`Removing background ${index+1} of ${sources.length}: ${row.filename}`});
      let result;
      if(applySavedMask) {
        await fs.mkdir(maskFolder,{recursive:true});
        await fs.copyFile(providedMask,mask,require('node:fs').constants.COPYFILE_EXCL);
        result={source:row.source,mask,width:providedMaskInfo.oriented_dimensions[0],height:providedMaskInfo.oriented_dimensions[1],mode:'grayscale',method:'provided_coverage_mask',provided_mask:providedMask,coverage_semantics:'multiply-source-alpha-once',needs_visual_review:true};
      } else {
        const maskArgs=[row.source,'--output',mask,'--model',model,'--model-dir',models,'--runtime-dir',runtime,'--threads','2'];
        if(request.force_segment)maskArgs.push('--force-segment');
        result=await runTool(path.join(helpers,'generate_mask.cjs'),maskArgs);
      }
      Object.assign(report.items[index],{source_png:path.join(sourceFolder,row.filename),mask,...{mask_report:result}});
      completed++;
      await core.atomicJson(reportPath,report);
      if(result.method==='preserve_existing_alpha') emit({kind:'notice',message:`${row.filename}: existing transparency was preserved. Review the cutout; choose re-segmentation only if background remains.`});
    }
    emit({kind:'progress',completed,total,message:`Saving ${sources.length} transparent cutout${sources.length===1?'':'s'} without resizing.`});
    await fs.writeFile(cutoutManifest,JSON.stringify(sources.map(({source,filename})=>({source,filename,mask:path.join(maskFolder,filename)})),null,2),{flag:'wx'});
    await runTool(path.join(helpers,'asset_pipeline.cjs'),['export',cutoutManifest,'--output-dir',cutoutFolder,'--runtime-dir',runtime]);
    for(let index=0;index<sources.length;index++) {
      const item=report.items[index],cutout=path.join(cutoutFolder,item.filename);
      if(await core.sha256(item.source)!==item.source_sha256) throw new Error(`The source changed during this batch: ${item.source}. Review the saved files before using them.`);
      Object.assign(item,{cutout,source_png_sha256:await core.sha256(item.source_png),mask_sha256:await core.sha256(item.mask),cutout_sha256:await core.sha256(cutout),dimensions:[item.mask_report.width,item.mask_report.height],status:'complete'});
    }
    const sourceCheck=await runTool(path.join(helpers,'asset_pipeline.cjs'),['verify',sourceFolder,'--runtime-dir',runtime]);
    const cutoutCheck=await runTool(path.join(helpers,'asset_pipeline.cjs'),['verify',cutoutFolder,'--runtime-dir',runtime]);
    if(sourceCheck.status!=='ok'||cutoutCheck.status!=='ok') throw new Error('Output integrity verification did not pass. See asset-manifest.json in the output folders.');
    report.status='complete';
    report.needs_visual_review=true;
    report.note='Inspect every garment edge, strap, lace opening, fringe and accessory before using the cutouts.';
    await core.atomicJson(reportPath,report);
    emit({kind:'complete',completed:total,total,folder,count:sources.length,message:`Finished ${sources.length} image${sources.length===1?'':'s'}. Open Cutouts to review; Sources PNG and Masks are ready for the mask editor.`});
    return {folder,report};
  } catch(error) {
    report.status='error';report.error=messageFrom(error);report.completed_steps=completed;
    await core.atomicJson(reportPath,report).catch(()=>{});
    emit({kind:'error',folder,completed,total,message:`Stopped: ${messageFrom(error)} Existing outputs and sources were preserved.`});
    error.reported=true;
    throw error;
  }
}

if(require.main===module)execute(optionsFrom(process.argv.slice(2))).catch(error=>{if(!error.reported)emit({kind:'error',message:`Stopped: ${messageFrom(error)}`});process.exitCode=1;});
module.exports={optionsFrom,execute,batchTimestamp,runTool};
