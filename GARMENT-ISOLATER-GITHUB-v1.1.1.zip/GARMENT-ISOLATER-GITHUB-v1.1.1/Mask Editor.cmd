@echo off
setlocal
if not exist "%~dp0mask-editor.html" (
  echo The mask editor file is missing. Keep this launcher with its extracted tool folder.
  pause
  exit /b 1
)
start "" "%~dp0mask-editor.html"
endlocal
