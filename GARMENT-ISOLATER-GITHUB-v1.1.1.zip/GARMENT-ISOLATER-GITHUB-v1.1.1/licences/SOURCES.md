# Third-party sources

Full licence texts are retained in this directory. `THIRD-PARTY-LICENCES.txt` consolidates the remaining supplied native-library and npm notices, identifying each original relative notice filename. Downloaded npm packages also retain their upstream notices.

- [Node.js 24.19.0](https://nodejs.org/dist/v24.19.0/) — portable engine and bundled npm; full licence and official checksum list included.
- [sharp 0.35.5](https://github.com/lovell/sharp/tree/v0.35.5) — image processing.
- [sharp/libvips notices](https://github.com/lovell/sharp-libvips) — native image-library dependencies with their respective licences.
- [ONNX Runtime 1.30.0](https://github.com/microsoft/onnxruntime/tree/v1.30.0) — local model inference.
- [U-2-Net](https://github.com/xuebinqin/U-2-Net) — U2NET model project, Apache 2.0.
- [rembg 2.0.85](https://github.com/danielgatis/rembg/tree/v2.0.85) — pinned model recipes and model-release hosting, MIT.

These dependency notices apply to their respective third-party components. This source export does not assign a new licence to the locally authored GARMENT ISOLATER code.
