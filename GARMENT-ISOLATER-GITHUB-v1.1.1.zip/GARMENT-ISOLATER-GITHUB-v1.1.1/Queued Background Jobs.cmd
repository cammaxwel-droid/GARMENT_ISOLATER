@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Background Remover.ps1" -ExplorerQueue "%LOCALAPPDATA%\GARMENT-ISOLATER\Explorer\Queue"
