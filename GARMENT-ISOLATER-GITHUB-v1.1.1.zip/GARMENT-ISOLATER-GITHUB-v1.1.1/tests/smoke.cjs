'use strict';
// Portable self-test. Creates only synthetic fixtures in a fresh OS temp folder.
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function check(ok,message){if(!ok)throw Error(message);}
async function main(){
 const root=path.resolve(__dirname,'..'),runtime=path.join(root,'runtime');
 const sharp=require(path.join(runtime,'node_modules','sharp'));sharp.cache(false);sharp.concurrency(1);
 const runner=require(path.join(root,'scripts','manual_batch.cjs'));
 const scratch=await fs.mkdtemp(path.join(os.tmpdir(),'garment-isolater-self-test-'));
 const inputs=path.join(scratch,'inputs'),outputs=path.join(scratch,'outputs');await fs.mkdir(inputs);await fs.mkdir(outputs);
 const svg=Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="192" height="256"><rect width="192" height="256" fill="white"/><path fill="#243964" d="M48 50L76 35H116L144 50L178 92L151 115L133 92V230H59V92L41 115L14 92Z"/></svg>');
 const opaque=path.join(inputs,'synthetic_opaque.png');await fs.writeFile(opaque,await sharp(svg).removeAlpha().png().toBuffer(),{flag:'wx'});
 const rgba=Buffer.alloc(32*24*4);for(let p=0;p<32*24;p++){rgba[p*4]=(p*7)%256;rgba[p*4+1]=(p*11)%256;rgba[p*4+2]=(p*17)%256;rgba[p*4+3]=[0,96,192,255][p%4];}
 const transparent=path.join(inputs,'synthetic_alpha.png');await fs.writeFile(transparent,await sharp(rgba,{raw:{width:32,height:24,channels:4}}).png().toBuffer(),{flag:'wx'});
 const sources=[opaque,transparent],hashes=await Promise.all(sources.map(async f=>sha(await fs.readFile(f))));
 const request=path.join(scratch,'request.json');await fs.writeFile(request,JSON.stringify({mode:'remove',sources,output_parent:outputs,model:'u2net',force_segment:false}),{flag:'wx'});
 console.log('Testing one opaque U2NET inference and one existing-alpha image. Originals are synthetic.');
 const result=await runner.execute({request,'runtime-dir':runtime,'model-dir':path.join(root,'models'),'helpers-dir':path.join(root,'helpers')});
 check(result.report.status==='complete'&&result.report.items.length===2,'Expected two completed synthetic images.');
 let center,corner;
 for(let n=0;n<sources.length;n++){
  check(sha(await fs.readFile(sources[n]))===hashes[n],'Synthetic original changed.');
  const row=result.report.items.find(r=>r.source===sources[n]);check(row,'Missing synthetic receipt.');
  const source=await sharp(sources[n],{ignoreIcc:true}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  const copy=await sharp(row.source_png,{ignoreIcc:true}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  const cutout=await sharp(row.cutout,{ignoreIcc:true}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  const mask=await sharp(row.mask).toColourspace('b-w').raw().toBuffer();
  check(source.data.equals(copy.data),'Source PNG RGBA did not match the synthetic original.');
  check(cutout.info.width===source.info.width&&cutout.info.height===source.info.height,'Native dimensions changed.');
  for(let p=0;p<mask.length;p++){
   for(let c=0;c<3;c++)check(cutout.data[p*4+c]===source.data[p*4+c],'Cutout RGB changed.');
   check(cutout.data[p*4+3]===Math.floor(source.data[p*4+3]*mask[p]/255),'Coverage was not applied to source alpha exactly once.');
  }
  if(n===0){check(row.mask_report.method==='onnx:u2net','Opaque source did not use U2NET.');center=mask[140*192+96];corner=mask[0];check(center>200&&corner<40,'Synthetic foreground/background inference check failed.');}
  else{check(row.mask_report.method==='preserve_existing_alpha','Existing transparency was not preserved.');check(cutout.data.equals(source.data),'Existing-alpha cutout differs from the original.');}
 }
 const partialMask=path.join(scratch,'partial_coverage.png');
 await fs.writeFile(partialMask,await sharp(Buffer.alloc(32*24,127),{raw:{width:32,height:24,channels:1}}).toColourspace('b-w').png().toBuffer(),{flag:'wx'});
 const applyRequest=path.join(scratch,'apply_request.json');await fs.writeFile(applyRequest,JSON.stringify({mode:'apply_mask',sources:[transparent],output_parent:outputs,mask:partialMask}),{flag:'wx'});
 const applied=await runner.execute({request:applyRequest,'runtime-dir':runtime,'model-dir':path.join(root,'models'),'helpers-dir':path.join(root,'helpers')});
 check(applied.report.status==='complete'&&applied.report.items.length===1,'Saved-mask application did not complete.');
 const appliedPixels=await sharp(applied.report.items[0].cutout,{ignoreIcc:true}).ensureAlpha().raw().toBuffer();
 for(let p=0;p<32*24;p++){
  for(let c=0;c<3;c++)check(appliedPixels[p*4+c]===rgba[p*4+c],'Saved-mask application changed RGB.');
  check(appliedPixels[p*4+3]===Math.floor(rgba[p*4+3]*127/255),'Partial mask was not multiplied into source alpha exactly once.');
 }
 check(sha(await fs.readFile(transparent))===hashes[1],'Saved-mask application changed the original.');
 console.log(JSON.stringify({self_test:'PASS',synthetic_images:2,opaque_inferences:1,preserved_alpha_images:1,saved_partial_mask_applications:1,native_dimensions_preserved:true,rgb_preserved:true,alpha_applied_once:true,originals_unchanged:true,center,corner,node:process.version,sharp:sharp.versions.sharp},null,2));
 console.log('Synthetic test files are retained in: '+scratch);
}
main().catch(e=>{console.error('Self-test FAIL: '+e.message);process.exitCode=1;});
