@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup_windows.ps1" %*
set "GARMENT_SETUP_EXIT=%ERRORLEVEL%"
echo.
if not "%GARMENT_SETUP_EXIT%"=="0" echo Setup did not finish. Read the error above before trying again.
pause
exit /b %GARMENT_SETUP_EXIT%
