@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Background Remover.ps1"
if errorlevel 1 (
  echo.
  echo The Background Remover stopped. Read the message above.
  pause
)
endlocal
