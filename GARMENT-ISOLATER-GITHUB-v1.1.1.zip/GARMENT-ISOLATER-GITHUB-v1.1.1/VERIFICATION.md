# Source package verification

Checked on 13 October 2026 on Windows x64.

## Passed

- All 19 existing application, Explorer adapter/source and dependency-manifest files match the installed 1.1.1 manual-tools release byte for byte. Packaging did not change the installed tool.
- A clean source archive was extracted to a separate OS temp folder. Windows PowerShell completed first-run setup from that extraction: official pinned Node download, locked npm dependencies, both checked U2NET model downloads, native library loading and a PNG round trip.
- An opaque synthetic T-shirt completed a real U2NET inference. Foreground coverage at its centre was 255; background coverage at the corner was 0.
- A synthetic image with existing transparency retained its original RGBA pixels.
- A saved grayscale mask with coverage 127 was applied to that synthetic source. RGB stayed unchanged; output alpha equalled `floor(source_alpha * 127 / 255)` for every pixel.
- Source hashes and native dimensions stayed unchanged during the image tests. Test images were synthetic; personal clothing images were not processed.
- The remover's path-readiness check passed, and its Windows form controls were constructed without opening an interactive window.
- Setup's read-only check verified the downloaded runtime, dependency versions and both models, and reported ready for offline processing.
- The source archive passed its file-size, manifest, launcher-reference, personal-path and credential-pattern checks. No personal images, generated batches, runtime binaries, model weights or caches are included.

`Test Tools.cmd` repeats the synthetic image checks after setup. Test output stays in a fresh OS temp folder.

## Scope

Explorer registration and interactive browser file selection were not repeated during packaging. Their implementation files are unchanged. The 101-image batch test was not repeated for this source export. Synthetic inference establishes functional operation; it does not guarantee mask quality for every garment. Review fine details as described in the README.

The final source ZIP adds documentation and a refreshed integrity manifest to the tested source files. `PACKAGE-MANIFEST.json` records the SHA-256 and size of every included file except itself. Downloads have separate pins in `DEPENDENCIES.json`.
