@echo off
setlocal
if not exist "%~dp0runtime\node.exe" (
  echo Run Setup Windows.cmd first.
  pause
  exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0tests\smoke.cjs"
if errorlevel 1 (
  echo.
  echo The self-test stopped. Read the message above.
)
pause
endlocal
